package library_management_system_web_test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.*;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;

class MainServerTest {

    private static Thread serverThread;

    @BeforeAll
    static void startServer() throws Exception {
        serverThread = new Thread(() -> {
            try {
                library_management_system_web.MainServer.main(null);
            } catch (Exception e) {
                e.printStackTrace();
            }
        });
        serverThread.setDaemon(true); // JVM can exit after tests
        serverThread.start();

        // Give server time to start
        Thread.sleep(1000);
    }

    @Test
    void testBooksEndpointAvailable() throws IOException {
        URL url = new URL("http://localhost:8080/books");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        assertTrue(responseCode == 200 || responseCode == 405);
    }

    @Test
    void testUsersEndpointAvailable() throws IOException {
        URL url = new URL("http://localhost:8080/users");
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");

        int responseCode = connection.getResponseCode();
        assertTrue(responseCode == 200 || responseCode == 405);
    }
}
