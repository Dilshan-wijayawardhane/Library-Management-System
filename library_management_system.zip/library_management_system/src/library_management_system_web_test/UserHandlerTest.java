package library_management_system_web_test;

import static org.junit.jupiter.api.Assertions.*;

import com.sun.net.httpserver.HttpServer;
import library_management_system_web.UserHandler;
import org.junit.jupiter.api.*;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.URL;

class UserHandlerTest {

    private static HttpServer server;
    private static final int PORT = 8081;

    @BeforeAll
    static void startServer() throws Exception {
        server = HttpServer.create(new InetSocketAddress(PORT), 0);
        server.createContext("/users", new UserHandler());
        server.start();

        // Allow server time to boot
        Thread.sleep(500);
    }

    @AfterAll
    static void stopServer() {
        server.stop(0);
    }

    @Test
    void testGetAllUsersReturns200() throws Exception {
        URL url = new URL("http://localhost:" + PORT + "/users");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        int responseCode = conn.getResponseCode();
        assertEquals(200, responseCode);
    }

    @Test
    void testGetAllUsersReturnsHtmlPage() throws Exception {
        URL url = new URL("http://localhost:" + PORT + "/users");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader reader =
                new BufferedReader(new InputStreamReader(conn.getInputStream()));

        StringBuilder response = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) {
            response.append(line);
        }

        String html = response.toString();

        assertTrue(html.contains("<html>"));
        assertTrue(html.contains("Library Users"));
        assertTrue(html.contains("<table>"));
    }

    @Test
    void testInvalidMethodReturns405() throws Exception {
        URL url = new URL("http://localhost:" + PORT + "/users");
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("TRACE"); // ✅ supported by HttpURLConnection

        int responseCode = conn.getResponseCode();
        assertEquals(405, responseCode);
    }

}
