package library_management_system;

public class Lecturer extends User {
    public Lecturer(String userID, String username, String password) {
        super(userID, username, password, Role.LECTURER);
    }
}
