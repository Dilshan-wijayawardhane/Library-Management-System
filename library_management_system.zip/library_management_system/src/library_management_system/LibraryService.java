package library_management_system;

import library_management_system_dao.BookDAO;
import library_management_system_dao.BorrowRecordDAO;
import java.util.*;

public class LibraryService {

    private final List<LibraryItem> items = new ArrayList<>();
    private final List<BorrowRecord> borrowRecords = new ArrayList<>();

   
    private final BookDAO bookDAO = new BookDAO();
    private final BorrowRecordDAO borrowDAO = new BorrowRecordDAO();

    public LibraryService() {
       
        items.add(new Book("B1001", "Java Programming", "James Gosling"));
        items.add(new Book("B1002", "Data Structures", "Robert Lafore"));

        
        items.addAll(bookDAO.getAllBooksFromDB());
        borrowRecords.addAll(borrowDAO.getAllBorrowRecordsFromDB());
    }

    public List<LibraryItem> getAllItems() {
        return Collections.unmodifiableList(items);
    }

    public void addItem(LibraryItem item) {
        items.add(item);
        if (item instanceof Book) {
            bookDAO.addBook((Book) item);
        }
    }

    public boolean removeItem(String id) {
        boolean removed = items.removeIf(i -> i.getId().equals(id));
        if (removed) {
            if (id.startsWith("B")) bookDAO.deleteBook(id); 
        }
        return removed;
    }

    public Optional<LibraryItem> findItemById(String id) {
        return items.stream().filter(i -> i.getId().equals(id)).findFirst();
    }

    public boolean isBookIdExists(String id) {
        return items.stream()
                .filter(i -> i instanceof Book)
                .anyMatch(i -> i.getId().equalsIgnoreCase(id));
    }

    public boolean borrowItem(User user, String id) {
        Optional<LibraryItem> item = findItemById(id);
        if (item.isPresent() && item.get().borrow()) {
            BorrowRecord record = new BorrowRecord(user, item.get());
            borrowRecords.add(record);

          
            borrowDAO.saveBorrowRecord(user, item.get());
            return true;
        }
        return false;
    }

    public boolean returnItem(String id) {
        Optional<LibraryItem> item = findItemById(id);
        if (item.isPresent() && item.get().isBorrowed()) {

            item.get().returned();

            borrowRecords.stream()
                    .filter(r -> r.getItem().getId().equals(id) && r.getReturnDate() == null)
                    .findFirst()
                    .ifPresent(BorrowRecord::markReturned);

          
            borrowDAO.markReturned(id);

            return true;
        }
        return false;
    }

    public List<BorrowRecord> getBorrowRecords() {
        return Collections.unmodifiableList(borrowRecords);
    }
}
