package library_management_system;

public class Newspaper extends LibraryItem {
    private String publisher;

    public Newspaper(String id, String title, String publisher) {
        super(id, title);
        this.publisher = publisher;
    }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    @Override
    public String toString() {
        return getId() + " | " + getTitle() + " | " + publisher + " | Borrowed: " + isBorrowed();
    }
}