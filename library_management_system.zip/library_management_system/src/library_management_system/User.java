package library_management_system;
public class User {
    private String userID;
    private String username;
    private String password;
    private Role role;

    public User(String userID, String username, String password, Role role) {
        this.userID = userID;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    public String getUserID() { return userID; }
    public String getUsername() { return username; }
    public Role getRole() { return role; }

    public boolean checkPassword(String input) {
        return this.password.equals(input);
    }

    @Override
    public String toString() {
        return userID + " - " + username + " - " + role;
    }
}
