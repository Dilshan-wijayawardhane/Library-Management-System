package library_management_system;

public enum Role {
    ADMIN,
    LIBRARIAN,
    STUDENT,
    LECTURER,
    STAFF
}
