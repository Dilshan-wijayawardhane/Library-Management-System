package library_management_system;

public class Staff extends User {
    public Staff(String userID, String username, String password) {
        super(userID, username, password, Role.STAFF);
    }
}
