package library_management_system;

public interface Borrowable {
   
    boolean borrow();

   
    void returned();

   
    boolean isBorrowed();
}

