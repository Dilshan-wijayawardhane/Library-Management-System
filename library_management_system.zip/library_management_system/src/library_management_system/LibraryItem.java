
package library_management_system;

public abstract class LibraryItem implements Borrowable {
    private final String id;
    private String title;
    private boolean borrowed;

    public LibraryItem(String id, String title) {
        this.id = id;
        this.title = title;
        this.borrowed = false;
    }

    public String getId() { return id; }
    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    @Override
    public boolean isBorrowed() { return borrowed; }

    @Override
    public boolean borrow() {
        if (borrowed) return false;
        borrowed = true;
        return true;
    }

    @Override
    public void returned() {
        borrowed = false;
    }
}
