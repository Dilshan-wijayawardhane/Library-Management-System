package library_management_system;

public class CD extends LibraryItem {
    private String publisher;

    public CD(String id, String title, String publisher) {
        super(id, title);
        this.publisher = publisher;
    }

    public String getPublisher() { return publisher; }
    public void setPublisher(String publisher) { this.publisher = publisher; }

    @Override
    public String toString() {
        return getId() + " | " + getTitle() + " | " + publisher + " | Borrowed: " + isBorrowed();
    }
}