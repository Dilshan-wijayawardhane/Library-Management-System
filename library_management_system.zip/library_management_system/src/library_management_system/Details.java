
package library_management_system;

import javax.swing.SwingUtilities;

import library_management_system_GUI.LoginGUI;

public class Details {
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            LoginGUI login = new LoginGUI();
            login.setVisible(true);
        });
    }
}
