package library_management_system;

import java.time.LocalDate;

public class BorrowRecord {
    private final User user;
    private final LibraryItem item;
    private LocalDate borrowDate;
    private LocalDate returnDate;

   
    public BorrowRecord(User user, LibraryItem item) {
        this.user = user;
        this.item = item;
        this.borrowDate = LocalDate.now();
    }

    
    public BorrowRecord(User user, LibraryItem item, LocalDate borrowDate, LocalDate returnDate) {
        this.user = user;
        this.item = item;
        this.borrowDate = borrowDate;
        this.returnDate = returnDate;
    }

    public User getUser() { return user; }
    public LibraryItem getItem() { return item; }

    public LocalDate getBorrowDate() { return borrowDate; }
    public void setBorrowDate(LocalDate borrowDate) { this.borrowDate = borrowDate; }

    public LocalDate getReturnDate() { return returnDate; }
    public void setReturnDate(LocalDate returnDate) { this.returnDate = returnDate; }

    public void markReturned() { this.returnDate = LocalDate.now(); }

    @Override
    public String toString() {
        return String.format("Record[user=%s,item=%s,borrow=%s,return=%s]",
                user.getUserID(), 
                item.getTitle(),
                borrowDate,
                (returnDate == null ? "N/A" : returnDate));
    }
}
