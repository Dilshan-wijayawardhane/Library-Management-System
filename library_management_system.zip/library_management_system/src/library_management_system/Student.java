package library_management_system;

public class Student extends User {
    public Student(String userID, String username, String password) {
        super(userID, username, password, Role.STUDENT);
    }
}
