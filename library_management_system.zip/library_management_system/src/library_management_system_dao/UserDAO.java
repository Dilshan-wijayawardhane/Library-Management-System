package library_management_system_dao;

import library_management_system.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO class for User entity.
 * Handles CRUD operations with the database.
 */
public class UserDAO {

   
    public boolean save(User user, String password) {
        if (!user.getUserID().matches("^U\\d+$")) {
            System.out.println("Invalid user ID! Must start with 'U' followed by numbers.");
            return false;
        }
        String sql = "INSERT INTO User (user_id, username, password, role) VALUES (?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, user.getUserID());
            stmt.setString(2, user.getUsername());
            stmt.setString(3, password); 
            stmt.setString(4, user.getRole().name());
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

  
    public User findById(String id) {
        String sql = "SELECT username, password, role FROM User WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, id);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String username = rs.getString("username");
                String password = rs.getString("password");
                Role role = Role.valueOf(rs.getString("role"));
                return new User(id, username, password, role);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

    
    public User findByUsername(String uname) {
        String sql = "SELECT user_id, password, role FROM User WHERE username = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uname);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                String id = rs.getString("user_id");
                String password = rs.getString("password");
                Role role = Role.valueOf(rs.getString("role"));
                return new User(id, uname, password, role);
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return null;
    }

   
    public boolean update(User user, String password) {
        String sql = "UPDATE User SET username = ?, password = ?, role = ? WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, user.getUsername());
            stmt.setString(2, password);
            stmt.setString(3, user.getRole().name());
            stmt.setString(4, user.getUserID());
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

   
    public boolean delete(String id) {
        String sql = "DELETE FROM User WHERE user_id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, id);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) { e.printStackTrace(); }
        return false;
    }

   
    public List<User> search(String usernameQuery, Role roleFilter) {
        List<User> list = new ArrayList<>();
        String sql = "SELECT user_id, username, password, role FROM User WHERE username LIKE ?";
        if (roleFilter != null) sql += " AND role = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, "%" + usernameQuery + "%");
            if (roleFilter != null) ps.setString(2, roleFilter.name());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                String id = rs.getString("user_id");
                String uname = rs.getString("username");
                String password = rs.getString("password");
                Role role = Role.valueOf(rs.getString("role"));
                list.add(new User(id, uname, password, role));
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return list;
    }
	public List<User> findAll() {
    List<User> list = new ArrayList<>();
    String sql = "SELECT user_id, username, password, role FROM User";
    try (Connection conn = DBConnection.getConnection();
         PreparedStatement ps = conn.prepareStatement(sql);
         ResultSet rs = ps.executeQuery()) {
        while (rs.next()) {
            String id = rs.getString("user_id");
            String uname = rs.getString("username");
            String password = rs.getString("password");
            Role role = Role.valueOf(rs.getString("role"));
            list.add(new User(id, uname, password, role));
        }
    } catch (SQLException e) { e.printStackTrace(); }
    return list;
}

}
