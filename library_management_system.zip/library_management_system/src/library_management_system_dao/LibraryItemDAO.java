package library_management_system_dao;

import library_management_system.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * DAO class for LibraryItem entity.
 * Handles CRUD operations with the database for all item types.
 */
public class LibraryItemDAO {

   

    public boolean save(LibraryItem item) {
        if (!item.getId().matches("^LI\\d+$")) {
            System.out.println("Invalid Item ID! Must start with 'LI' followed by numbers.");
            return false;
        }

        String bookId = item.getId().replaceFirst("^LI", "B");
        String itemSql = "INSERT INTO LibraryItem (item_id, title, borrowed, type, author) VALUES (?,?,?,?,?)";
        String bookSql = "INSERT INTO Book (book_id, title, author, borrowed) VALUES (?,?,?,?)";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(itemSql)) {
                ps.setString(1, item.getId());
                ps.setString(2, item.getTitle());
                ps.setBoolean(3, item.isBorrowed());

                if (item instanceof Book) {
                    ps.setString(4, "Book");
                    ps.setString(5, ((Book) item).getAuthor());
                } else if (item instanceof CD) {
                    ps.setString(4, "CD");
                    ps.setString(5, ((CD) item).getPublisher());
                } else if (item instanceof Magazine) {
                    ps.setString(4, "Magazine");
                    ps.setString(5, ((Magazine) item).getPublisher());
                } else if (item instanceof Newspaper) {
                    ps.setString(4, "Newspaper");
                    ps.setString(5, ((Newspaper) item).getPublisher());
                }

                ps.executeUpdate();
            }

            if (item instanceof Book) {
                Book book = (Book) item;
                try (PreparedStatement psBook = conn.prepareStatement(bookSql)) {
                    psBook.setString(1, bookId);
                    psBook.setString(2, book.getTitle());
                    psBook.setString(3, book.getAuthor());
                    psBook.setBoolean(4, book.isBorrowed());
                    psBook.executeUpdate();
                }
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    

    public LibraryItem getById(String itemId) {
        String sql = "SELECT * FROM LibraryItem WHERE item_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, itemId);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) return mapToObject(rs);

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

  

    public List<LibraryItem> getAll() {
        List<LibraryItem> list = new ArrayList<>();
        String sql = "SELECT * FROM LibraryItem";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                list.add(mapToObject(rs));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return list;
    }

    

    public boolean update(LibraryItem item) {

        String updateLibraryItemSQL =
                "UPDATE LibraryItem SET title=?, borrowed=?, author=?, type=? WHERE item_id=?";
        String updateBookSQL =
                "UPDATE Book SET title=?, author=?, borrowed=? WHERE book_id=?";

        String bookId = item.getId().replaceFirst("^LI", "B");

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps = conn.prepareStatement(updateLibraryItemSQL)) {

                ps.setString(1, item.getTitle());
                ps.setBoolean(2, item.isBorrowed());

                if (item instanceof Book) {
                    ps.setString(3, ((Book) item).getAuthor());
                    ps.setString(4, "Book");
                } else if (item instanceof CD) {
                    ps.setString(3, ((CD) item).getPublisher());
                    ps.setString(4, "CD");
                } else if (item instanceof Magazine) {
                    ps.setString(3, ((Magazine) item).getPublisher());
                    ps.setString(4, "Magazine");
                } else if (item instanceof Newspaper) {
                    ps.setString(3, ((Newspaper) item).getPublisher());
                    ps.setString(4, "Newspaper");
                }

                ps.setString(5, item.getId());

                if (ps.executeUpdate() == 0) {
                    conn.rollback();
                    return false;
                }
            }

            if (item instanceof Book) {
                Book book = (Book) item;
                try (PreparedStatement psBook = conn.prepareStatement(updateBookSQL)) {
                    psBook.setString(1, book.getTitle());
                    psBook.setString(2, book.getAuthor());
                    psBook.setBoolean(3, book.isBorrowed());
                    psBook.setString(4, bookId);

                    if (psBook.executeUpdate() == 0) {
                        conn.rollback();
                        return false;
                    }
                }
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

  

    public boolean delete(String itemId) {

        String deleteLibraryItemSQL = "DELETE FROM LibraryItem WHERE item_id=?";
        String deleteBookSQL = "DELETE FROM Book WHERE book_id=?";

        try (Connection conn = DBConnection.getConnection()) {
            conn.setAutoCommit(false);

            try (PreparedStatement ps1 = conn.prepareStatement(deleteLibraryItemSQL)) {
                ps1.setString(1, itemId);
                if (ps1.executeUpdate() == 0) {
                    conn.rollback();
                    return false;
                }
            }

            String bookId = itemId.replaceFirst("^LI", "B");
            try (PreparedStatement ps2 = conn.prepareStatement(deleteBookSQL)) {
                ps2.setString(1, bookId);
                ps2.executeUpdate();
            }

            conn.commit();
            return true;

        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

   

    private LibraryItem mapToObject(ResultSet rs) throws SQLException {

        String id = rs.getString("item_id");
        String title = rs.getString("title");
        boolean borrowed = rs.getBoolean("borrowed");
        String type = rs.getString("type");
        String authorOrPublisher = rs.getString("author");

        LibraryItem item = null;

        switch (type) {
            case "Book":
                item = new Book(id, title, authorOrPublisher);
                break;
            case "CD":
                item = new CD(id, title, authorOrPublisher);
                break;
            case "Magazine":
                item = new Magazine(id, title, authorOrPublisher);
                break;
            case "Newspaper":
                item = new Newspaper(id, title, authorOrPublisher);
                break;
        }

        if (borrowed && item != null) item.borrow();
        return item;
    }

    

    public boolean markBorrowed(String itemId) {
        String sql = "UPDATE LibraryItem SET borrowed=TRUE WHERE item_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, itemId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    public boolean markReturned(String itemId) {
        String sql = "UPDATE LibraryItem SET borrowed=FALSE WHERE item_id=?";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, itemId);
            return ps.executeUpdate() > 0;

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

  

 
    public List<String[]> getAllItemsForDashboardothers() {
        List<String[]> list = new ArrayList<>();

        String sql =
            "SELECT li.item_id, li.title, li.author, li.borrowed, li.type, " +
            "       br.borrow_date, br.return_date " +
            "FROM LibraryItem li " +
            "LEFT JOIN ( " +
            "    SELECT br1.* " +
            "    FROM BorrowRecord br1 " +
            "    WHERE br1.record_id = ( " +
            "        SELECT MAX(br2.record_id) " +
            "        FROM BorrowRecord br2 " +
            "        WHERE br2.item_id = br1.item_id " +
            "    ) " +
            ") br ON li.item_id = br.item_id";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                String author = rs.getString("author");
                if (author == null) author = "-";

                String borrowDate = rs.getDate("borrow_date") != null
                        ? rs.getDate("borrow_date").toString()
                        : "";

                String returnDate = rs.getDate("return_date") != null
                        ? rs.getDate("return_date").toString()
                        : "";

                list.add(new String[]{
                    rs.getString("item_id"),
                    rs.getString("title"),
                    author,
                    rs.getBoolean("borrowed") ? "Borrowed" : "Available",
                    rs.getString("type"),
                    borrowDate,
                    returnDate
                });
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return list;
    }


}
