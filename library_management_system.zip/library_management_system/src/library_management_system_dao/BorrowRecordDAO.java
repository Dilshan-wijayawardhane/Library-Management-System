package library_management_system_dao;

import library_management_system.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BorrowRecordDAO {

   
    public boolean saveBorrowRecord(User user, LibraryItem item) {
        String sql = "INSERT INTO BorrowRecord (user_id, item_id, borrow_date) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, user.getUserID());
            ps.setString(2, item.getId());
            ps.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error saving borrow record: " + e.getMessage());
            return false;
        }
    }

    
    public boolean saveBorrowRecord(String userId, String itemId) {
        String sql = "INSERT INTO BorrowRecord (user_id, item_id, borrow_date) VALUES (?, ?, ?)";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, userId);
            ps.setString(2, itemId);
            ps.setDate(3, java.sql.Date.valueOf(LocalDate.now()));
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error saving borrow record: " + e.getMessage());
            return false;
        }
    }

   
    public boolean markReturned(String itemId) {
        String sql = "UPDATE BorrowRecord " +
                     "SET return_date = ? " +
                     "WHERE item_id = ? " +
                     "AND borrow_date = (" +
                     "   SELECT MAX(borrow_date) FROM BorrowRecord WHERE item_id = ?" +
                     ") AND return_date IS NULL";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setDate(1, java.sql.Date.valueOf(LocalDate.now()));
            ps.setString(2, itemId);
            ps.setString(3, itemId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error marking return: " + e.getMessage());
            return false;
        }
    }

   
    public List<BorrowRecord> getAllBorrowRecordsFromDB() {
        List<BorrowRecord> list = new ArrayList<>();
        String sql = "SELECT * FROM BorrowRecord";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            LibraryItemDAO itemDAO = new LibraryItemDAO();
            while (rs.next()) {
                User user = new User(rs.getString("user_id"), "", "", null);
                LibraryItem item = itemDAO.getById(rs.getString("item_id"));
                if (item != null) {
                    BorrowRecord record = new BorrowRecord(user, item);
                    if (rs.getDate("borrow_date") != null) {
                        record.setBorrowDate(rs.getDate("borrow_date").toLocalDate());
                    }
                    if (rs.getDate("return_date") != null) {
                        record.setReturnDate(rs.getDate("return_date").toLocalDate());
                    }
                    list.add(record);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching borrow records: " + e.getMessage());
        }
        return list;
    }

   
    public boolean deleteBorrowRecord(String itemId) {
        String sql = "DELETE FROM BorrowRecord WHERE item_id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, itemId);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("Error deleting borrow record: " + e.getMessage());
            return false;
        }
    }
}
