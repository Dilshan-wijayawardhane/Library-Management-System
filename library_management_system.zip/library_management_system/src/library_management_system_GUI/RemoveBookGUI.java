package library_management_system_GUI;

import library_management_system.*;
import java.awt.*;
import javax.swing.*;

public class RemoveBookGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBookID;
    private LibraryService libraryService;

    public RemoveBookGUI(LibraryService libraryService) {
        this.libraryService = libraryService;

        setTitle("Remove Book");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 250);
        setLocationRelativeTo(null);

        contentPane = new BackgroundPanel("images (3).png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Remove Book");
        lblTitle.setBounds(130, 10, 200, 40);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 24));
        contentPane.add(lblTitle);

        JLabel lblBookID = new JLabel("Book ID:");
        lblBookID.setForeground(Color.WHITE);
        lblBookID.setBounds(50, 70, 100, 25);
        lblBookID.setFont(new Font("Times New Roman", Font.BOLD, 20));
        contentPane.add(lblBookID);

        txtBookID = new JTextField();
        txtBookID.setBounds(150, 70, 200, 25);
        contentPane.add(txtBookID);

        JButton btnRemove = new JButton("Remove Book");
        btnRemove.setBounds(130, 130, 180, 40);
        btnRemove.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnRemove.setBackground(new Color(220, 53, 69));
        btnRemove.setForeground(Color.WHITE);
        contentPane.add(btnRemove);

        btnRemove.addActionListener(e -> {
            String id = txtBookID.getText().trim();
            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a Book ID!", "Error", JOptionPane.ERROR_MESSAGE);
            }
            if (!id.matches("^B\\d+$")) {
                JOptionPane.showMessageDialog(this, "Invalid Book ID! Must start with 'B' followed by numbers.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            else {
                boolean removed = libraryService.removeItem(id);
                if (removed)
                    JOptionPane.showMessageDialog(null, "Book with ID " + id + " removed successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                else
                    JOptionPane.showMessageDialog(null, "Book ID not found!", "Error", JOptionPane.ERROR_MESSAGE);
                txtBookID.setText("");
            }
        });

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(20, 130, 90, 40);
        backBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        backBtn.addActionListener(e -> dispose());
        contentPane.add(backBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(330, 130, 90, 40);
        exitBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        exitBtn.addActionListener(e -> System.exit(0));
        contentPane.add(exitBtn);
    }
}
