package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.UserDAO;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.ArrayList;
import java.util.List;

public class LoginGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUsername;
    private JPasswordField txtPassword;

    private List<User> userList = new ArrayList<>();
    private UserDAO userDAO = new UserDAO(); 

    public LoginGUI() {

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(900, 550);
        setLocationRelativeTo(null);
        setResizable(true);
        setExtendedState(JFrame.NORMAL);

        contentPane = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                ImageIcon bg = new ImageIcon("library.jpg");
                g.drawImage(bg.getImage(), 0, 0, getWidth(), getHeight(), null);
            }
        };
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblMainTitle = new JLabel("Library Management System");
        lblMainTitle.setForeground(Color.WHITE);
        lblMainTitle.setFont(new Font("Segoe UI", Font.BOLD, 34));
        lblMainTitle.setHorizontalAlignment(SwingConstants.CENTER);
        contentPane.add(lblMainTitle);

        JPanel glass = new JPanel();
        glass.setLayout(null);
        glass.setBackground(new Color(255, 255, 255, 70));
        glass.setSize(380, 320);
        glass.setBorder(BorderFactory.createLineBorder(Color.WHITE, 2));
        contentPane.add(glass);

        JLabel lblTitle = new JLabel("Login Page");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
        lblTitle.setBounds(0, 15, 380, 40);
        glass.add(lblTitle);

        JLabel lblUsername = new JLabel("User Name :");
        lblUsername.setForeground(Color.WHITE);
        lblUsername.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblUsername.setBounds(40, 90, 120, 25);
        glass.add(lblUsername);

        txtUsername = new JTextField(); 
        txtUsername.setBounds(160, 90, 180, 25);
        txtUsername.setBackground(new Color(240, 240, 240));
        txtUsername.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        glass.add(txtUsername);

        JLabel lblPassword = new JLabel("Password :");
        lblPassword.setForeground(Color.WHITE);
        lblPassword.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblPassword.setBounds(40, 140, 120, 25);
        glass.add(lblPassword);

        txtPassword = new JPasswordField();
        txtPassword.setBounds(160, 140, 180, 25);
        txtPassword.setEchoChar('•');
        txtPassword.setBackground(new Color(240, 240, 240));
        txtPassword.setBorder(BorderFactory.createLineBorder(Color.WHITE));
        glass.add(txtPassword);

        
        userList.add(new User("U001", "admin", "admin1234#", Role.ADMIN));
        userList.add(new User("U002", "librarian", "librarian1234#", Role.LIBRARIAN));
        userList.add(new User("U003", "student1", "student11234#", Role.STUDENT));
        userList.add(new User("U004", "lect1", "lect11234#", Role.LECTURER));
        userList.add(new User("U005", "staff1", "staff1234#", Role.STAFF));

        JButton btnLogin = new JButton("Login");
        btnLogin.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnLogin.setBounds(60, 210, 110, 35);
        btnLogin.setBackground(Color.WHITE);
        glass.add(btnLogin);

        btnLogin.addActionListener(e -> {
            String username = new String(txtUsername.getText().trim());
            String password = new String(txtPassword.getPassword());
            User loggedUser = null;

           
            for (User u : userList) {
                if (u.getUsername().equals(username) && u.checkPassword(password)) {
                    loggedUser = u;
                    break;
                }
            }

          
            if (loggedUser == null) {
                User dbUser = userDAO.findByUsername(username);
                if (dbUser != null && dbUser.checkPassword(password)) {
                    loggedUser = dbUser;
                }
            }

          
            if (loggedUser != null) {
                Role role = loggedUser.getRole();
                if (role == Role.ADMIN) {
                    new DashboardGUI().setVisible(true);
                } else {
                    new DashboardothersGUI(loggedUser.getUserID()).setVisible(true);
                }
                dispose();
            } else {
                JOptionPane.showMessageDialog(null,
                        "Invalid Username or Password!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        });

        JButton btnExit = new JButton("Exit");
        btnExit.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnExit.setBounds(200, 210, 110, 35);
        btnExit.setBackground(Color.WHITE);
        glass.add(btnExit);

        btnExit.addActionListener(e -> System.exit(0));

        addComponentListener(new ComponentAdapter() {
            @Override
            public void componentResized(ComponentEvent e) {
                glass.setLocation((getWidth() - glass.getWidth()) / 2,
                        (getHeight() - glass.getHeight()) / 2);
                lblMainTitle.setBounds(0, glass.getY() - 70, getWidth(), 50);
                contentPane.revalidate();
                contentPane.repaint();
            }
        });

        lblMainTitle.setBounds(0, glass.getY() - 70, getWidth(), 50);
    }
}