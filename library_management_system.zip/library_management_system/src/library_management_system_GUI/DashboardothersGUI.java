package library_management_system_GUI;
import library_management_system.*;
import library_management_system_dao.*;

import java.awt.*;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;

public class DashboardothersGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JPanel mainPanel;
    private List<String[]> itemList = new ArrayList<>();
    private  String loggedUserId ;
    private BorrowRecordDAO borrowRecordDAO = new BorrowRecordDAO();
    private LibraryItemDAO libraryItemDAO = new LibraryItemDAO();



    public DashboardothersGUI(String userId) {
    	this.loggedUserId = userId;
        setTitle("Library Dashboard - User: " + loggedUserId);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 700, 500);

        contentPane = new BackgroundPanel("other.png");
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(new BorderLayout());
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Library Management System", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Arial", Font.BOLD, 28));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBorder(new EmptyBorder(20, 0, 20, 0));
        contentPane.add(lblTitle, BorderLayout.NORTH);

        mainPanel = new JPanel();
        mainPanel.setOpaque(false);
        mainPanel.setLayout(new BorderLayout());
        contentPane.add(mainPanel, BorderLayout.CENTER);
        
        loadAllLibraryItems();
        showViewItemsPanel();

        JMenuBar menuBar = new JMenuBar();
        JMenu menuLibrary = new JMenu("Menu");
        menuLibrary.setFont(new Font("Arial", Font.BOLD, 16));

        JMenuItem viewBooksItem = new JMenuItem("View Items");
        viewBooksItem.addActionListener(e -> showViewItemsPanel());
        menuLibrary.add(viewBooksItem);

        JMenuItem borrowBooksItem = new JMenuItem("Borrow Items");
        borrowBooksItem.addActionListener(e -> showBorrowItemsPanel());
        menuLibrary.add(borrowBooksItem);

        JMenuItem returnBooksItem = new JMenuItem("Return Items");
        returnBooksItem.addActionListener(e -> showReturnItemsPanel());
        menuLibrary.add(returnBooksItem);

        menuLibrary.addSeparator();

        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        menuLibrary.add(exitItem);

        menuBar.add(menuLibrary);
        setJMenuBar(menuBar);
    }

    
    private void loadAllLibraryItems(){
        itemList = libraryItemDAO.getAllItemsForDashboardothers();
    }

   
    private void showHomePanel() {
        mainPanel.removeAll();
        mainPanel.revalidate();
        mainPanel.repaint();
    }

    private JPanel createTopPanelWithBack() {
        JPanel topPanel = new JPanel(new BorderLayout());
        topPanel.setOpaque(false);
        JButton btnBack = new JButton("Back");
        btnBack.addActionListener(e -> showHomePanel());
        JPanel rightPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        rightPanel.setOpaque(false);
        rightPanel.add(btnBack);
        topPanel.add(rightPanel, BorderLayout.NORTH);
        return topPanel;
    }

   
    private void showViewItemsPanel() {
        loadAllLibraryItems();
        mainPanel.removeAll();
        String[] columns = {"Item ID", "Title", "Author", "Status", "Type", "Borrow Date", "Return Date"};
        DefaultTableModel model = new DefaultTableModel(columns, 0);

        for (String[] item : itemList) {
            model.addRow(item);
        }

        JTable table = new JTable(model);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);

        JPanel panelWithBack = new JPanel(new BorderLayout());
        panelWithBack.setOpaque(false);
        panelWithBack.add(createTopPanelWithBack(), BorderLayout.NORTH);
        panelWithBack.add(scrollPane, BorderLayout.CENTER);

        mainPanel.add(panelWithBack, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }

   
    private void showBorrowItemsPanel() {
        mainPanel.removeAll();
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        panel.setOpaque(false);

        JLabel label = new JLabel("Item ID:");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 26));
        panel.add(label);

        JTextField txtItemID = new JTextField();
        txtItemID.setPreferredSize(new Dimension(200, 30));
        txtItemID.setFont(new Font("Arial", Font.PLAIN, 20));
        panel.add(txtItemID);

        JButton btnBorrow = new JButton("Borrow Item");
        btnBorrow.setFont(new Font("Arial", Font.BOLD, 20)); 
        panel.add(btnBorrow);

        JLabel lblMessage = new JLabel();
        lblMessage.setForeground(Color.WHITE);
        lblMessage.setFont(new Font("Arial", Font.PLAIN, 18)); 
        panel.add(lblMessage);

        btnBorrow.addActionListener(e -> {
            String itemId = txtItemID.getText().trim();
            boolean found = false;

            for (String[] item : itemList) {
                if (item[0].equalsIgnoreCase(itemId)) {
                    found = true;

                    if (item[3].equals("Available")) {
                        boolean itemUpdated = libraryItemDAO.markBorrowed(itemId);
                        boolean recordSaved = borrowRecordDAO.saveBorrowRecord(loggedUserId, itemId);

                        if (itemUpdated && recordSaved) {
                            item[3] = "Borrowed";
                            item[5] = LocalDate.now().toString();
                            item[6] = "";

                          
                            JOptionPane.showMessageDialog(
                                mainPanel,
                                "Item borrowed successfully",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE
                            );

                            loadAllLibraryItems(); 
                            showViewItemsPanel();   
                        } else {
                            lblMessage.setText("Borrow failed");
                        }
                    } else {
                        lblMessage.setText("Item already borrowed");
                    }
                    break;
                }
            }
            if (!found) lblMessage.setText("Item not found");
        });

        JPanel panelWithBack = new JPanel(new BorderLayout());
        panelWithBack.setOpaque(false);
        panelWithBack.add(createTopPanelWithBack(), BorderLayout.NORTH);
        panelWithBack.add(panel, BorderLayout.CENTER);
        mainPanel.add(panelWithBack, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }


 
    private void showReturnItemsPanel() {
        mainPanel.removeAll();
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10)); 
        panel.setOpaque(false);

        JLabel label = new JLabel("Item ID:");
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 26));
        panel.add(label);

        JTextField txtItemID = new JTextField();
        txtItemID.setPreferredSize(new Dimension(200, 30));
        txtItemID.setFont(new Font("Arial", Font.PLAIN, 20));
        panel.add(txtItemID);

        JButton btnReturn = new JButton("Return Item");
        btnReturn.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(btnReturn);

        JLabel lblMessage = new JLabel();
        lblMessage.setForeground(Color.WHITE);
        lblMessage.setFont(new Font("Arial", Font.PLAIN, 18));
        panel.add(lblMessage);

        btnReturn.addActionListener(e -> {
            String itemId = txtItemID.getText().trim();
            boolean found = false;

            for (String[] item : itemList) {
                if (item[0].equalsIgnoreCase(itemId)) {
                    found = true;

                    if (item[3].equals("Borrowed")) {
                        boolean itemUpdated = libraryItemDAO.markReturned(itemId);
                        boolean recordUpdated = borrowRecordDAO.markReturned(itemId);

                        if (itemUpdated && recordUpdated) {
                            item[3] = "Available";
                            item[6] = LocalDate.now().toString();

                          
                            JOptionPane.showMessageDialog(
                                mainPanel,
                                "Item returned successfully",
                                "Success",
                                JOptionPane.INFORMATION_MESSAGE
                            );

                            loadAllLibraryItems(); 
                            showBorrowItemsPanel(); 
                        } else {
                            lblMessage.setText("Return failed");
                        }
                    } else {
                        lblMessage.setText("Item is not borrowed");
                    }
                    break;
                }
            }

            if (!found) lblMessage.setText("Item not found");
        });

        JPanel panelWithBack = new JPanel(new BorderLayout());
        panelWithBack.setOpaque(false);
        panelWithBack.add(createTopPanelWithBack(), BorderLayout.NORTH);
        panelWithBack.add(panel, BorderLayout.CENTER);
        mainPanel.add(panelWithBack, BorderLayout.CENTER);
        mainPanel.revalidate();
        mainPanel.repaint();
    }


}