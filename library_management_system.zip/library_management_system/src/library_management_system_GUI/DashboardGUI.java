package library_management_system_GUI;
import library_management_system.*;

import java.awt.*;
import java.util.ArrayList;
import java.util.List;
import javax.swing.*;
import javax.swing.border.EmptyBorder;

public class DashboardGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private List<User> userList = new ArrayList<>();
    private LibraryService libraryService = new LibraryService();

    public DashboardGUI() {
        setTitle("Library Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setBounds(100, 100, 600, 400);

        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(40, 40, 40));
        menuBar.setBorderPainted(false);
        setJMenuBar(menuBar);

        Font menuFont = new Font("Segoe UI", Font.BOLD, 14);
        UIManager.put("MenuItem.selectionBackground", new Color(70, 130, 180));
        UIManager.put("MenuItem.selectionForeground", Color.WHITE);

    
        JMenu mnFile = new JMenu("File");
        mnFile.setForeground(Color.WHITE);
        mnFile.setFont(menuFont);
        menuBar.add(mnFile);
        mnFile.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JMenuItem mntmExit = new JMenuItem("Exit");
        mntmExit.setFont(menuFont);
        mnFile.add(mntmExit);
        mntmExit.addActionListener(e -> System.exit(0));

       
        JMenu mnUsers = new JMenu("Users");
        mnUsers.setForeground(Color.WHITE);
        mnUsers.setFont(menuFont);
        menuBar.add(mnUsers);
        mnUsers.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JMenuItem mntmAddUser = new JMenuItem("Add User");
        mntmAddUser.setFont(menuFont);
        mnUsers.add(mntmAddUser);
        mntmAddUser.addActionListener(e -> new AddUserGUI(userList).setVisible(true));

        JMenuItem mntmViewUsers = new JMenuItem("View Users");
        mntmViewUsers.setFont(menuFont);
        mnUsers.add(mntmViewUsers);
        mntmViewUsers.addActionListener(e -> new ViewUserGUI(userList).setVisible(true));

        JMenuItem mntmSearchUser = new JMenuItem("Search User");
        mntmSearchUser.setFont(menuFont);
        mnUsers.add(mntmSearchUser);
        mntmSearchUser.addActionListener(e -> new SearchUserGUI(userList).setVisible(true));
        

        JMenuItem mntmUpdateUser = new JMenuItem("Update User");
        mntmUpdateUser.setFont(menuFont);
        mnUsers.add(mntmUpdateUser);
        mntmUpdateUser.addActionListener(e -> new UpdateUserGUI(libraryService).setVisible(true));

        JMenuItem mntmRemoveUser = new JMenuItem("Remove User");
        mntmRemoveUser.setFont(menuFont);
        mnUsers.add(mntmRemoveUser);
        mntmRemoveUser.addActionListener(e -> new RemoveUserGUI(userList).setVisible(true));

        
        JMenu mnBooks = new JMenu("Books");
        mnBooks.setForeground(Color.WHITE);
        mnBooks.setFont(menuFont);
        menuBar.add(mnBooks);
        mnBooks.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JMenuItem mntmAddBook = new JMenuItem("Add Book");
        mntmAddBook.setFont(menuFont);
        mnBooks.add(mntmAddBook);
        mntmAddBook.addActionListener(e -> new AddBookGUI(libraryService).setVisible(true));

        JMenuItem mntmViewBooks = new JMenuItem("View Books");
        mntmViewBooks.setFont(menuFont);
        mnBooks.add(mntmViewBooks);
        mntmViewBooks.addActionListener(e -> new ViewBooksGUI(libraryService).setVisible(true));

        JMenuItem mntmSearchBook = new JMenuItem("Search Book");
        mntmSearchBook.setFont(menuFont);
        mnBooks.add(mntmSearchBook);
        mntmSearchBook.addActionListener(e -> new SearchBookGUI(libraryService).setVisible(true));
        
        JMenuItem mntmUpdateBook = new JMenuItem("Update Book");
        mntmUpdateBook.setFont(menuFont);
        mnBooks.add(mntmUpdateBook);
        mntmUpdateBook.addActionListener(e -> new UpdateBookGUI(libraryService).setVisible(true));

        JMenuItem mntmRemoveBook = new JMenuItem("Remove Book");
        mntmRemoveBook.setFont(menuFont);
        mnBooks.add(mntmRemoveBook);
        mntmRemoveBook.addActionListener(e -> new RemoveBookGUI(libraryService).setVisible(true));
        

        JMenu mnItem = new JMenu("Item");
        mnItem.setForeground(Color.WHITE);
        mnItem.setFont(menuFont);
        menuBar.add(mnItem);
        mnItem.setCursor(new Cursor(Cursor.HAND_CURSOR));

        JMenuItem mntmAddItem = new JMenuItem("Add Item");
        mntmAddItem.setFont(menuFont);
        mnItem.add(mntmAddItem);
        mntmAddItem.addActionListener(e -> new AddLibraryItemGUI(userList).setVisible(true));
        
        
        JMenuItem mntmViewItem = new JMenuItem("View Item");
        mntmViewItem.setFont(menuFont);
        mnItem.add(mntmViewItem);
        mntmViewItem.addActionListener(e -> new ViewLibraryItemsGUI(userList).setVisible(true));
        
        JMenuItem mntmUpdateItem = new JMenuItem("Update Item");
        mntmUpdateItem.setFont(menuFont);
        mnItem.add(mntmUpdateItem);
        mntmUpdateItem.addActionListener(e -> new UpdateLibraryItemGUI(libraryService).setVisible(true));

        JMenuItem mntmRemoveItem = new JMenuItem("Remove Item");
        mntmRemoveItem.setFont(menuFont);
        mnItem.add(mntmRemoveItem);
        mntmRemoveItem.addActionListener(e -> new DeleteLibraryItemGUI(userList).setVisible(true));

       JButton btnLogout=new JButton("Logout");
       btnLogout.setFont(new Font("Segoe UI",Font.BOLD,14));
       btnLogout.setForeground(Color.WHITE);
       btnLogout.setBackground(new Color(200,0,0));
       btnLogout.setOpaque(true);
       btnLogout.setBorderPainted(false);
       btnLogout.setFocusable(false);
       btnLogout.setCursor(new Cursor(Cursor.HAND_CURSOR));
       
       btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
    	   public void mouseEntered(java.awt.event.MouseEvent evt) {
    		   btnLogout.setBackground(new Color(255,50,50));
    	   }
    	   public void mouseExited(java.awt.event.MouseEvent evt) {
    		   btnLogout.setBackground(new Color(200,0,0));
    	   }
       });
       btnLogout.addActionListener(e->{
    	   int result=JOptionPane.showConfirmDialog(
    			   null,
    			   "Do You Want To Logout?",
    			   "Conirm Logout",
    			   JOptionPane.YES_NO_OPTION,
    			   JOptionPane.WARNING_MESSAGE
    			   );
    	   if(result==JOptionPane.YES_OPTION) {
    		   dispose();
    		   new LoginGUI().setVisible(true);
    	   }
       });
       
       menuBar.add(Box.createHorizontalGlue());
       menuBar.add(btnLogout);

       

      
        contentPane = new JPanel() {
            private Image bgImage = new ImageIcon("dashboard.png").getImage();

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            }
        };
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

      
        JPanel titleBackground = new JPanel();
        titleBackground.setBackground(new Color(0, 0, 0, 120));
        titleBackground.setLayout(new BorderLayout());
        contentPane.add(titleBackground);

        JLabel lblTitle = new JLabel("Library Dashboard", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 40));
        lblTitle.setForeground(Color.WHITE);
        titleBackground.add(lblTitle, BorderLayout.CENTER);

       
        contentPane.addComponentListener(new java.awt.event.ComponentAdapter() {
            public void componentResized(java.awt.event.ComponentEvent evt) {
                int panelWidth = contentPane.getWidth();
                int panelHeight = contentPane.getHeight();
                titleBackground.setBounds(panelWidth/2 - 250, panelHeight/2 - 30, 500, 60);
            }
        });

       
        contentPane.setSize(getWidth(), getHeight());
        contentPane.dispatchEvent(new java.awt.event.ComponentEvent(contentPane, java.awt.event.ComponentEvent.COMPONENT_RESIZED));
    }
}
