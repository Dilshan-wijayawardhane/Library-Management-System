package library_management_system_GUI;

import library_management_system_dao.*;
import library_management_system.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ItemEvent;
import java.util.List;

public class AddLibraryItemGUI extends JFrame {

    private JTextField txtId, txtTitle, txtAuthor;
    private JButton btnAdd;
    private JComboBox<String> cbType;
    private JLabel lblAuthor;
    private final LibraryItemDAO libraryItemDAO = new LibraryItemDAO();

    public AddLibraryItemGUI(List<User> userList) {
        setTitle("Add Library Item");
        setSize(438, 250);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        
        ImageIcon bgIcon = new ImageIcon("additem.png"); 
        Image bgImage = bgIcon.getImage();

       
        JPanel backgroundPanel = new JPanel(new GridLayout(5, 2, 5, 5)) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

       
        Font labelFont = new Font("Arial", Font.BOLD, 14);

        
        JLabel lblType = new JLabel("Item Type:");
        lblType.setFont(labelFont);
        lblType.setForeground(Color.BLACK);
        backgroundPanel.add(lblType);

        cbType = new JComboBox<>(new String[]{"Book", "Magazine", "CD", "Newspaper"});
        backgroundPanel.add(cbType);

        JLabel lblId = new JLabel("Item ID:");
        lblId.setFont(labelFont);
        lblId.setForeground(Color.BLACK);
        backgroundPanel.add(lblId);

        txtId = new JTextField();
        backgroundPanel.add(txtId);

        JLabel lblTitle = new JLabel("Title:");
        lblTitle.setFont(labelFont);
        lblTitle.setForeground(Color.BLACK);
        backgroundPanel.add(lblTitle);

        txtTitle = new JTextField();
        backgroundPanel.add(txtTitle);

        lblAuthor = new JLabel("Author (for Book):");
        lblAuthor.setFont(labelFont);
        lblAuthor.setForeground(Color.BLACK);
        backgroundPanel.add(lblAuthor);

        txtAuthor = new JTextField();
        backgroundPanel.add(txtAuthor);

        btnAdd = new JButton("Add Item");
        backgroundPanel.add(new JLabel()); 
        backgroundPanel.add(btnAdd);

        
        setContentPane(backgroundPanel);

      
        cbType.addItemListener(e -> {
            if (e.getStateChange() == ItemEvent.SELECTED) {
                String type = (String) cbType.getSelectedItem();
                if ("Book".equals(type)) lblAuthor.setText("Author (for Book):");
                else lblAuthor.setText("Publisher (for " + type + "):");
            }
        });

       
        btnAdd.addActionListener((ActionEvent e) -> {
            String type = (String) cbType.getSelectedItem();
            String id = txtId.getText().trim();
            String title = txtTitle.getText().trim();
            String author = txtAuthor.getText().trim();

            if (id.isEmpty() || title.isEmpty() || author.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            if (!id.matches("^LI\\d+$")) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Item ID! Must start with 'LI' followed by numbers.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            LibraryItem item = null;
            switch (type) {
                case "Book": item = new Book(id, title, author); break;
                case "Magazine": item = new Magazine(id, title, author); break;
                case "CD": item = new CD(id, title, author); break;
                case "Newspaper": item = new Newspaper(id, title, author); break;
            }

            if (item != null) {
                boolean saved = libraryItemDAO.save(item);
                if (saved)
                    JOptionPane.showMessageDialog(this, type + " saved successfully!");
                else
                    JOptionPane.showMessageDialog(this, "Failed to save " + type + "!", "Error", JOptionPane.ERROR_MESSAGE);

             
                txtId.setText("");
                txtTitle.setText("");
                txtAuthor.setText("");
                cbType.setSelectedIndex(0);
            }
        });

        setVisible(true);
    }
}
