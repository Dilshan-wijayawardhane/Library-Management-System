package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class UpdateLibraryItemGUI extends JFrame {

    private JTextField txtItemId, txtTitle, txtAuthorPublisher;
    private JCheckBox chkBorrowed;
    private JButton btnSearch, btnUpdate;
    private final LibraryItemDAO libraryItemDAO = new LibraryItemDAO();
    private LibraryItem currentItem;

    public UpdateLibraryItemGUI(LibraryService libraryService) {

        setTitle("Update Library Item");
        setSize(450, 330);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

      
        ImageIcon bgIcon = new ImageIcon("updateitem (1).png"); 
        Image bgImage = bgIcon.getImage();

      
        JPanel panel = new JPanel(new GridBagLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

        
        Font labelFont = new Font("Arial", Font.BOLD, 14);

        
        c.gridx = 0; c.gridy = 0;
        JLabel lblId = new JLabel("Item ID:");
        lblId.setFont(labelFont);
        lblId.setForeground(Color.BLACK);
        panel.add(lblId, c);

        c.gridx = 1;
        txtItemId = new JTextField(15);
        panel.add(txtItemId, c);

        c.gridx = 2;
        btnSearch = new JButton("Search");
        panel.add(btnSearch, c);

       
        c.gridx = 0; c.gridy = 1;
        JLabel lblTitle = new JLabel("Title:");
        lblTitle.setFont(labelFont);
        lblTitle.setForeground(Color.BLACK);
        panel.add(lblTitle, c);

        c.gridx = 1; c.gridwidth = 2;
        txtTitle = new JTextField();
        txtTitle.setEnabled(false);
        panel.add(txtTitle, c);
        c.gridwidth = 1;

       
        c.gridx = 0; c.gridy = 2;
        JLabel lblAuthorPublisher = new JLabel("Author / Publisher:");
        lblAuthorPublisher.setFont(labelFont);
        lblAuthorPublisher.setForeground(Color.BLACK);
        panel.add(lblAuthorPublisher, c);

        c.gridx = 1; c.gridwidth = 2;
        txtAuthorPublisher = new JTextField();
        txtAuthorPublisher.setEnabled(false);
        panel.add(txtAuthorPublisher, c);
        c.gridwidth = 1;

      
        c.gridx = 0; c.gridy = 3;
        JLabel lblBorrowed = new JLabel("Borrowed:");
        lblBorrowed.setFont(labelFont);
        lblBorrowed.setForeground(Color.BLACK);
        panel.add(lblBorrowed, c);

        c.gridx = 1;
        chkBorrowed = new JCheckBox();
        chkBorrowed.setEnabled(false);
        panel.add(chkBorrowed, c);

        
        c.gridx = 1; c.gridy = 4;
        btnUpdate = new JButton("Update Item");
        btnUpdate.setEnabled(false);
        panel.add(btnUpdate, c);

        
        c.gridx = 0; c.gridy = 5;
        c.gridwidth = 3;
        c.anchor = GridBagConstraints.CENTER;

        JButton btnBack = new JButton("Back");
        btnBack.setPreferredSize(new Dimension(120, 35));
        btnBack.setBackground(new Color(220, 20, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        panel.add(btnBack, c);

        setContentPane(panel);

       
        btnSearch.addActionListener(this::searchItem);
        btnUpdate.addActionListener(this::updateItem);
        btnBack.addActionListener(e -> dispose());

        setVisible(true);
    }

    
    private void searchItem(ActionEvent e) {
        String id = txtItemId.getText().trim();

        if (!id.matches("^LI\\d+$")) {
            JOptionPane.showMessageDialog(this,
                    "Invalid Item ID (LI123)",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        currentItem = libraryItemDAO.getById(id);

        if (currentItem == null) {
            JOptionPane.showMessageDialog(this,
                    "Item Not Found!",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        txtTitle.setEnabled(true);
        txtAuthorPublisher.setEnabled(true);
        chkBorrowed.setEnabled(true);
        btnUpdate.setEnabled(true);

        txtTitle.setText(currentItem.getTitle());
        chkBorrowed.setSelected(currentItem.isBorrowed());

        if (currentItem instanceof Book)
            txtAuthorPublisher.setText(((Book) currentItem).getAuthor());
        else if (currentItem instanceof CD)
            txtAuthorPublisher.setText(((CD) currentItem).getPublisher());
        else if (currentItem instanceof Magazine)
            txtAuthorPublisher.setText(((Magazine) currentItem).getPublisher());
        else if (currentItem instanceof Newspaper)
            txtAuthorPublisher.setText(((Newspaper) currentItem).getPublisher());
    }

   
    private void updateItem(ActionEvent e) {
        if (currentItem == null) return;

        currentItem.setTitle(txtTitle.getText().trim());

        if (currentItem instanceof Book)
            ((Book) currentItem).setAuthor(txtAuthorPublisher.getText().trim());
        else if (currentItem instanceof CD)
            ((CD) currentItem).setPublisher(txtAuthorPublisher.getText().trim());
        else if (currentItem instanceof Magazine)
            ((Magazine) currentItem).setPublisher(txtAuthorPublisher.getText().trim());
        else if (currentItem instanceof Newspaper)
            ((Newspaper) currentItem).setPublisher(txtAuthorPublisher.getText().trim());

        if (chkBorrowed.isSelected())
            currentItem.borrow();
        else
            currentItem.returned();

        boolean success = libraryItemDAO.update(currentItem);

        JOptionPane.showMessageDialog(this,
                success ? "Item Updated Successfully!" : "Update Failed!");
    }
}
