package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.util.List;

public class ViewLibraryItemsGUI extends JFrame {

    private JTable table;
    private JPanel contentPane;
    private final LibraryItemDAO libraryItemDAO = new LibraryItemDAO();

    public ViewLibraryItemsGUI(List<User> userList) {

        setTitle("View Library Items");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 650, 420);
        setLocationRelativeTo(null);
        
        JPanel contentPane = new BackgroundPanel("images (4).png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

       
        JLabel lblTitle = new JLabel("All Library Items", SwingConstants.CENTER);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitle.setBounds(150, 10, 350, 40);
        contentPane.add(lblTitle);

      
        table = new JTable();
        table.setFont(new Font("Tahoma", Font.PLAIN, 15));
        table.setRowHeight(26);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Tahoma", Font.BOLD, 15));
        header.setBackground(new Color(60, 63, 65));
        header.setForeground(Color.WHITE);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(40, 70, 560, 220);
        contentPane.add(scrollPane);

      
        JButton btnLoad = new JButton("Load Items");
        btnLoad.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnLoad.setBounds(240, 300, 160, 40);
        contentPane.add(btnLoad);

        btnLoad.addActionListener(e -> loadItems());

       
        JButton btnBack = new JButton("Back");
        btnBack.setBounds(40, 350, 90, 30);
        btnBack.addActionListener(e -> dispose());
        contentPane.add(btnBack);

        
        JButton btnExit = new JButton("Exit");
        btnExit.setBounds(510, 350, 90, 30);
        btnExit.addActionListener(e -> System.exit(0));
        contentPane.add(btnExit);
    }

    
    private void loadItems() {

    	List<LibraryItem> items = libraryItemDAO.getAll();
        DefaultTableModel model = new DefaultTableModel(
                new String[]{"Item ID", "Title", "Type", "Borrowed", "Author"}, 0
        ) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        for (LibraryItem item : items) {
            if (item == null) continue;

            String type = item.getClass().getSimpleName();
            String authorOrPublisher = "";

            if (item instanceof Book)
                authorOrPublisher = ((Book) item).getAuthor();
            else if (item instanceof Magazine)
                authorOrPublisher = ((Magazine) item).getPublisher();
            else if (item instanceof CD)
                authorOrPublisher = ((CD) item).getPublisher();
            else if (item instanceof Newspaper)
                authorOrPublisher = ((Newspaper) item).getPublisher();

            model.addRow(new Object[]{
                    item.getId(),
                    item.getTitle(),
                    type,
                    item.isBorrowed(),
                    authorOrPublisher
            });
        }

        table.setModel(model);
    }
}
