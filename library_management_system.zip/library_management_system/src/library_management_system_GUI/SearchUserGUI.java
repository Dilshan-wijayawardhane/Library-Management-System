package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.UserDAO;

import java.awt.*;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.util.List;
import java.util.stream.Collectors;

class BackgroundPanel2 extends JPanel {
    private Image bgImage;

    public BackgroundPanel2(String fileName) {
        bgImage = new ImageIcon(fileName).getImage();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        g.drawImage(bgImage, 0, 0, getWidth(), getHeight(), this);
    }
}

public class SearchUserGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtSearch;
    private JTextArea textAreaResults;
    private JComboBox<Role> comboRole;
    private List<User> userList;
    private UserDAO userDAO = new UserDAO(); 


    public SearchUserGUI(List<User> users) {
        this.userList = users;
        initializeGUI();
    }
    public SearchUserGUI(UserDAO userDAO) {
        this.userDAO = userDAO;
        initializeGUI();
    }

    
    private void initializeGUI() {
        setTitle("Search User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(520, 450);
        setLocationRelativeTo(null); 

       
        contentPane = new BackgroundPanel2("searchuser.png");
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        contentPane.setLayout(null);
        setContentPane(contentPane);

       
        JLabel lblSearch = new JLabel("Username:");
        lblSearch.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblSearch.setForeground(Color.WHITE);
        lblSearch.setBounds(30, 20, 100, 25);
        contentPane.add(lblSearch);

        JLabel lblRole = new JLabel("Role:");
        lblRole.setFont(new Font("Segoe UI", Font.BOLD, 16));
        lblRole.setForeground(Color.WHITE);
        lblRole.setBounds(30, 60, 100, 25);
        contentPane.add(lblRole);

       
        txtSearch = new JTextField();
        txtSearch.setBounds(140, 20, 220, 30);
        txtSearch.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtSearch.setBackground(new Color(255, 255, 255, 180)); 
        txtSearch.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
        contentPane.add(txtSearch);

      
        comboRole = new JComboBox<>(Role.values());
        comboRole.insertItemAt(null, 0);
        comboRole.setSelectedIndex(0);
        comboRole.setBounds(140, 60, 220, 30);
        comboRole.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        comboRole.setBackground(new Color(255, 255, 255, 180));
        contentPane.add(comboRole);

       
        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(380, 40, 100, 35);
        btnSearch.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSearch.setBackground(new Color(30, 144, 255));
        btnSearch.setForeground(Color.WHITE);
        btnSearch.setFocusPainted(false);
        btnSearch.addActionListener(e -> searchUsers());
        contentPane.add(btnSearch);

    
        textAreaResults = new JTextArea();
        textAreaResults.setEditable(false);
        textAreaResults.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        textAreaResults.setForeground(Color.BLACK);
        textAreaResults.setBackground(new Color(255, 255, 255, 180));
        textAreaResults.setBorder(BorderFactory.createLineBorder(Color.GRAY));

        JScrollPane scrollPane = new JScrollPane(textAreaResults);
        scrollPane.setBounds(30, 110, 450, 250);
        scrollPane.setOpaque(false);
        scrollPane.getViewport().setOpaque(false);
        contentPane.add(scrollPane);

     
        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 16));
        btnBack.setBounds(210, 375, 100, 35);
        btnBack.setBackground(new Color(220, 20, 60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.addActionListener(e -> dispose());
        contentPane.add(btnBack);
    }

    private void searchUsers() {
        String usernameQuery = txtSearch.getText().trim().toLowerCase();
        Role selectedRole = (Role) comboRole.getSelectedItem();
        
        List<User> results = userDAO.search(usernameQuery, selectedRole);
        textAreaResults.setText("");
        if (results.isEmpty()) {
            textAreaResults.setText("No users found.");
        } else {
            for (User u : results) {
                textAreaResults.append(u.toString() + "\n");
            }
        }
    }
}
