package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.UserDAO;
import java.awt.*;
import javax.swing.*;
import java.util.List;

public class RemoveUserGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtUserID;
    private List<User> userList;
    private JPanel glassPanel;
    private JLabel lblTitle;

    public RemoveUserGUI(List<User> users) {
        this.userList = users;
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("Remove User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 300);
        setMinimumSize(new Dimension(450, 250));

        contentPane = new BackgroundPanel("download.png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

        glassPanel = new JPanel() {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

                GradientPaint gp = new GradientPaint(0, 0, new Color(255, 255, 255, 200),
                        0, getHeight(), new Color(200, 200, 200, 150));

                g2.setPaint(gp);
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 25, 25);

                g2.setColor(new Color(0, 0, 0, 30));
                g2.fillRoundRect(5, 5, getWidth() - 10, getHeight() - 10, 25, 25);

                g2.dispose();
            }
        };
        glassPanel.setLayout(null);
        glassPanel.setBounds(50, 50, 400, 180);
        contentPane.add(glassPanel);

       
        lblTitle = new JLabel("Remove User", SwingConstants.CENTER);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitle.setBounds(0, 20, getWidth(), 40);
        contentPane.add(lblTitle);

       
        JLabel lblUserID = new JLabel("User ID:");
        lblUserID.setForeground(Color.BLACK);
        lblUserID.setFont(new Font("Tahoma", Font.BOLD, 20));
        lblUserID.setBounds(40, 40, 120, 25);
        glassPanel.add(lblUserID);

        txtUserID = new JTextField();
        txtUserID.setBounds(150, 40, 200, 25);
        glassPanel.add(txtUserID);

        
        JButton btnRemove = createButton("Remove User", new Color(220, 53, 69));
        btnRemove.setBounds(110, 90, 180, 40);
        glassPanel.add(btnRemove);

        btnRemove.addActionListener(e -> {
            String userID = txtUserID.getText().trim();
            if (userID.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please enter a User ID!", "Error", JOptionPane.ERROR_MESSAGE);
            }
           
            UserDAO userDAO = new UserDAO();
            boolean dbRemoved = userDAO.delete(userID);
            
            if (dbRemoved) {
              
                userList.removeIf(u -> u.getUserID().equals(userID));

                JOptionPane.showMessageDialog(null,
                        "User with ID " + userID + " removed successfully.",
                        "Success",
                        JOptionPane.INFORMATION_MESSAGE);
            } else {
                JOptionPane.showMessageDialog(null,
                        "User ID not found in database!",
                        "Error",
                        JOptionPane.ERROR_MESSAGE);
            }

            txtUserID.setText("");
        });


        JButton btnBack = createButton("Back", new Color(108, 117, 125));
        btnBack.setBounds(20, 90, 80, 40);
        glassPanel.add(btnBack);
        btnBack.addActionListener(e -> dispose());

        JButton btnExit = createButton("Exit", new Color(108, 117, 125));
        btnExit.setBounds(310, 90, 80, 40);
        glassPanel.add(btnExit);
        btnExit.addActionListener(e -> System.exit(0));

       
        addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {

                int w = getWidth();
                int h = getHeight();

                
                glassPanel.setBounds((w - 400) / 2, (h - 180) / 2, 400, 180);

              
                lblTitle.setBounds(glassPanel.getX(), glassPanel.getY() - 55, 400, 40);
            }
        });
    }

   
    private JButton createButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Tahoma", Font.BOLD, 16));
        btn.setForeground(Color.WHITE);
        btn.setBackground(color);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder());
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));

        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            @Override
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.darker());
            }
            @Override
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        return btn;
    }
}
