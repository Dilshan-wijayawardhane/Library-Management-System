package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.BookDAO;

import java.awt.*;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

public class ViewBooksGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable table;
    private LibraryService libraryService;

    public ViewBooksGUI(LibraryService libraryService) {
        this.libraryService = libraryService;

        setTitle("View Books");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 600, 400);
        setLocationRelativeTo(null);

        contentPane = new BackgroundPanel("images (4).png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("All Books", SwingConstants.CENTER);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 28));
        lblTitle.setBounds(150, 10, 300, 40);
        contentPane.add(lblTitle);

        table = new JTable();
        table.setFont(new Font("Tahoma", Font.PLAIN, 16));
        table.setRowHeight(28);

        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Tahoma", Font.BOLD, 16));
        header.setBackground(new Color(60, 63, 65));
        header.setForeground(Color.WHITE);

        table.setModel(new DefaultTableModel(
                new Object[][]{},
                new String[]{"ID", "Title", "Author"}
        ));

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(50, 70, 500, 200);
        contentPane.add(scrollPane);

        JButton btnLoad = new JButton("Load Books");
        btnLoad.setBounds(200, 280, 150, 40);
        btnLoad.setFont(new Font("Tahoma", Font.BOLD, 16));
        contentPane.add(btnLoad);

        btnLoad.addActionListener(e -> loadBooks());

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(50, 330, 90, 30);
        backBtn.addActionListener(e -> dispose());
        contentPane.add(backBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(460, 330, 90, 30);
        exitBtn.addActionListener(e -> System.exit(0));
        contentPane.add(exitBtn);
    }

   
    private void loadBooks() {
        DefaultTableModel model = (DefaultTableModel) table.getModel();
        model.setRowCount(0);

        Set<String> loadedIds = new HashSet<>();

       
        List<LibraryItem> memoryItems = libraryService.getAllItems();
        for (LibraryItem item : memoryItems) {
            if (item instanceof Book book) {
                model.addRow(new Object[]{
                        book.getId(),
                        book.getTitle(),
                        book.getAuthor()
                });
                loadedIds.add(book.getId());
            }
        }

        
        BookDAO bookDAO = new BookDAO();
        List<Book> books = bookDAO.getAllBooksFromDB();
        for (Book book : books) {
          
            if (!loadedIds.contains(book.getId())) {
                model.addRow(new Object[]{
                    book.getId(),
                    book.getTitle(),
                    book.getAuthor(),
                    book.isBorrowed()
                });
                loadedIds.add(book.getId());
            }
        }


        }
    }

