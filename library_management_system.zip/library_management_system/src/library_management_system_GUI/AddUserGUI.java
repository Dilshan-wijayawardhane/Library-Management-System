package library_management_system_GUI;

import library_management_system_dao.UserDAO;
import library_management_system.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import javax.swing.*;
import javax.swing.border.*;
import java.util.List;

public class AddUserGUI extends JFrame {
    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField textFieldUserID;
    private JTextField textFieldUserName;
    private JPasswordField passwordField;

    private JRadioButton rdbtnLibrarian;
    private JRadioButton rdbtnStudent;
    private JRadioButton rdbtnLecturer;
    private JRadioButton rdbtnStaff;
    private ButtonGroup buttonGroup;

    private List<User> userList;
    private UserDAO userDAO = new UserDAO();


    public AddUserGUI(List<User> users) {
        this.userList = users;
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("Add User");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setSize(600, 420);
        setLocationRelativeTo(null);

        
        contentPane = new BackgroundPanel("download (3).png");
        contentPane.setBorder(new EmptyBorder(20, 20, 20, 20));
        contentPane.setLayout(new GridBagLayout());
        setContentPane(contentPane);

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(12, 12, 12, 12);
        gbc.fill = GridBagConstraints.HORIZONTAL;

     
        JLabel lblTitle = new JLabel("Add User", SwingConstants.CENTER);
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 36));
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        contentPane.add(lblTitle, gbc);

       
        JPanel glassPanel = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(new Color(255, 255, 255, 100)); 
                g2.fillRoundRect(0, 0, getWidth(), getHeight(), 20, 20);
                g2.dispose();
                super.paintComponent(g);
            }
        };
        glassPanel.setOpaque(false);
        glassPanel.setBorder(new EmptyBorder(20, 20, 20, 20));
        glassPanel.setLayout(new GridBagLayout());

        GridBagConstraints fGbc = new GridBagConstraints();
        fGbc.insets = new Insets(10, 10, 10, 10);
        fGbc.fill = GridBagConstraints.HORIZONTAL;

      
        JLabel lblUserID = new JLabel("UserID:");
        JLabel lblPassword = new JLabel("Password:");
        JLabel lblUserName = new JLabel("User Name:");

        JLabel[] labels = {lblUserID, lblPassword, lblUserName};
        for (JLabel lbl : labels) {
            lbl.setForeground(Color.BLACK);
            lbl.setFont(new Font("Tahoma", Font.BOLD, 18));
        }

       
        textFieldUserID = new JTextField(20);
        textFieldUserID.setBorder(new CompoundBorder(new LineBorder(Color.WHITE, 2, true), new EmptyBorder(4, 8, 4, 8)));

        passwordField = new JPasswordField(20);
        passwordField.setBorder(new CompoundBorder(new LineBorder(Color.WHITE, 2, true), new EmptyBorder(4, 8, 4, 8)));

        textFieldUserName = new JTextField(20);
        textFieldUserName.setBorder(new CompoundBorder(new LineBorder(Color.WHITE, 2, true), new EmptyBorder(4, 8, 4, 8)));

     
        fGbc.gridx = 0; fGbc.gridy = 0;
        glassPanel.add(lblUserID, fGbc);
        fGbc.gridx = 1;
        glassPanel.add(textFieldUserID, fGbc);

        fGbc.gridx = 0; fGbc.gridy = 1;
        glassPanel.add(lblPassword, fGbc);
        fGbc.gridx = 1;
        glassPanel.add(passwordField, fGbc);

        fGbc.gridx = 0; fGbc.gridy = 2;
        glassPanel.add(lblUserName, fGbc);
        fGbc.gridx = 1;
        glassPanel.add(textFieldUserName, fGbc);

       
        rdbtnLibrarian = new JRadioButton("Librarian");
        rdbtnStudent = new JRadioButton("Student");
        rdbtnLecturer = new JRadioButton("Lecturer");
        rdbtnStaff = new JRadioButton("Staff");

        JRadioButton[] radios = {rdbtnLibrarian, rdbtnStudent, rdbtnLecturer, rdbtnStaff};
        buttonGroup = new ButtonGroup();
        for (JRadioButton rb : radios) {
            rb.setOpaque(false);
            rb.setForeground(Color.BLACK);
            rb.setFont(new Font("Tahoma", Font.BOLD, 16));
            buttonGroup.add(rb);
        }

        JPanel radioPanel = new JPanel(new GridLayout(1, 4, 20, 0));
        radioPanel.setOpaque(false);
        for (JRadioButton rb : radios) radioPanel.add(rb);

        fGbc.gridx = 0; fGbc.gridy = 3; fGbc.gridwidth = 2;
        glassPanel.add(radioPanel, fGbc);

       
        JButton btnAdd = new JButton("Add");
        JButton btnBack = new JButton("Back");
        JButton btnExit = new JButton("Exit");

        JButton[] buttons = {btnBack, btnAdd, btnExit};
        for (JButton btn : buttons) {
            btn.setFont(new Font("Tahoma", Font.BOLD, 18));
            btn.setFocusPainted(false);
            btn.setBackground(new Color(70, 130, 180));
            btn.setForeground(Color.WHITE);
            btn.setBorder(new LineBorder(Color.WHITE, 2, true));
        }

        btnAdd.addActionListener(e -> addUser());
        btnBack.addActionListener(e -> dispose());
        btnExit.addActionListener(e -> System.exit(0));

        JPanel buttonPanel = new JPanel(new GridLayout(1, 3, 20, 0));
        buttonPanel.setOpaque(false);
        buttonPanel.add(btnBack);
        buttonPanel.add(btnAdd);
        buttonPanel.add(btnExit);

        fGbc.gridx = 0; fGbc.gridy = 4; fGbc.gridwidth = 2;
        glassPanel.add(buttonPanel, fGbc);

       
        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 2;
        contentPane.add(glassPanel, gbc);
    }

    private void addUser() {
        String userID = textFieldUserID.getText().trim();
        String username = textFieldUserName.getText().trim();
        String password = new String(passwordField.getPassword()).trim();
        Role role = null;

        if (rdbtnLibrarian.isSelected()) role = Role.LIBRARIAN;
        else if (rdbtnStudent.isSelected()) role = Role.STUDENT;
        else if (rdbtnLecturer.isSelected()) role = Role.LECTURER;
        else if (rdbtnStaff.isSelected()) role = Role.STAFF;

       
        if (userID.isEmpty() || username.isEmpty() || password.isEmpty() || role == null) {
            JOptionPane.showMessageDialog(this, "Please fill all fields and select a role!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        if (userDAO.findById(userID) != null) {
            JOptionPane.showMessageDialog(this, "User ID already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!userID.matches("^U\\d+$")) {
            JOptionPane.showMessageDialog(this,
                    "Invalid USER ID! Must start with 'U' followed by numbers.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!password.matches("^(?=.*[a-zA-Z])(?=.*\\d).{8,}$")) {
            JOptionPane.showMessageDialog(this,
                    "Password must be at least 8 characters long and include at least one letter and one number.",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (userDAO.findByUsername(username) != null) {
            JOptionPane.showMessageDialog(this, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        
        User newUser = new User(userID, username, password, role);
        boolean saved = userDAO.save(newUser, password);

      
        if (saved) {
            JOptionPane.showMessageDialog(this, "User added successfully!");
            userList.add(newUser); 
            textFieldUserID.setText("");
            textFieldUserName.setText("");
            passwordField.setText("");
            buttonGroup.clearSelection();
        } else {
            JOptionPane.showMessageDialog(this, "Failed to add user. Check console for details.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}

