package library_management_system_GUI;

import library_management_system_dao.UserDAO;
import library_management_system.*;
import javax.swing.*;
import java.awt.*;

public class UpdateUserGUI extends JFrame {

    private JTextField txtUserID;
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JComboBox<Role> cbRole;

    private final UserDAO userDAO = new UserDAO();

    public UpdateUserGUI(LibraryService libraryService) {
        setTitle("Update User");
        setSize(400, 350);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        JPanel panel = new BackgroundPanel("updateuser.png");
        panel.setLayout(new GridLayout(6, 2, 10, 10));
        panel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

     
        txtUserID = new JTextField();
        txtUsername = new JTextField();
        txtPassword = new JPasswordField();
        cbRole = new JComboBox<>(Role.values());

        JButton btnLoad = new JButton("Load User");
        JButton btnUpdate = new JButton("Update User");

       
        JLabel lblUserID = new JLabel("User ID:");
        lblUserID.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblUserID.setForeground(Color.WHITE);
        panel.add(lblUserID);
        panel.add(txtUserID);

        panel.add(new JLabel("")); 
        panel.add(btnLoad);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblUsername.setForeground(Color.WHITE);
        panel.add(lblUsername);
        panel.add(txtUsername);

        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblPassword.setForeground(Color.WHITE);
        panel.add(lblPassword);
        panel.add(txtPassword);

        JLabel lblRole = new JLabel("Role:");
        lblRole.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblRole.setForeground(Color.WHITE);
        panel.add(lblRole);
        panel.add(cbRole);

        panel.add(new JLabel(""));
        panel.add(btnUpdate);

        add(panel);


       
        btnLoad.addActionListener(e -> {
            String id = txtUserID.getText().trim();

            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Enter a User ID!");
                return;
            }

            User user = userDAO.findById(id);
            if (user == null) {
                JOptionPane.showMessageDialog(this, "User not found!");
                return;
            }

            txtUsername.setText(user.getUsername());
            txtPassword.setText("*****"); // Masked
            cbRole.setSelectedItem(user.getRole());
        });

        
        btnUpdate.addActionListener(e -> {
            String id = txtUserID.getText().trim();
            String username = txtUsername.getText().trim();
            String password = new String(txtPassword.getPassword()).trim();
            Role role = (Role) cbRole.getSelectedItem();

            if (id.isEmpty() || username.isEmpty() || password.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Fill in all fields!");
                return;
            }
	        if (!password.matches("^(?=.*[a-zA-Z])(?=.*\\d).{8,}$")) {
                JOptionPane.showMessageDialog(this,
                        "Password must be at least 8 characters long and include at least one letter and one number.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
  

            User updatedUser = new User(id, username, password, role);
            boolean success = userDAO.update(updatedUser, password);
            if (success) {
                JOptionPane.showMessageDialog(this, "User updated successfully!");
            } else {
                JOptionPane.showMessageDialog(this, "Failed to update user.");
            }
        });
    }
}








