package library_management_system_GUI;

import library_management_system_dao.BookDAO;
import library_management_system.Book;
import library_management_system.LibraryService;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;

public class UpdateBookGUI extends JFrame {

    private JTextField txtBookId, txtTitle, txtAuthor;
    private JCheckBox chkBorrowed;
    private JButton btnSearch, btnUpdate, btnback;

    private final BookDAO bookDAO = new BookDAO();
    private Book currentBook = null;

    public UpdateBookGUI(LibraryService libraryService) {
        setTitle("Update Book");
        setSize(420, 320);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null); 

        
        JPanel panel = new JPanel(new GridBagLayout()) {
            private Image backgroundImage = new ImageIcon("updatebook.png").getImage(); 
           

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(backgroundImage, 0, 0, getWidth(), getHeight(), this);
            }
        };

        GridBagConstraints c = new GridBagConstraints();
        c.insets = new Insets(8, 8, 8, 8);
        c.fill = GridBagConstraints.HORIZONTAL;

       
        c.gridx = 0;  
        c.gridy = 0;
        panel.add(new JLabel("Book ID:"), c);

        c.gridx = 1;
        txtBookId = new JTextField(15);
        panel.add(txtBookId, c);

        c.gridx = 2;
        btnSearch = new JButton("Search");
        panel.add(btnSearch, c);

       
        c.gridx = 0;  
        c.gridy = 1;
        panel.add(new JLabel("Title:"), c);

        c.gridx = 1;
        c.gridwidth = 2;
        txtTitle = new JTextField();
        txtTitle.setEnabled(false);
        panel.add(txtTitle, c);
        c.gridwidth = 1;

      
        c.gridx = 0;  
        c.gridy = 2;
        panel.add(new JLabel("Author:"), c);

        c.gridx = 1;
        c.gridwidth = 2;
        txtAuthor = new JTextField();
        txtAuthor.setEnabled(false);
        panel.add(txtAuthor, c);
        c.gridwidth = 1;

     
        c.gridx = 0;  
        c.gridy = 3;
        panel.add(new JLabel("Borrowed:"), c);

        c.gridx = 1;
        chkBorrowed = new JCheckBox();
        chkBorrowed.setEnabled(false);
        panel.add(chkBorrowed, c);

        
        c.gridx = 1;  
        c.gridy = 4;
        btnUpdate = new JButton("Update Book");
        btnUpdate.setEnabled(false);
        panel.add(btnUpdate, c);

        add(panel);

      
        c.gridx = 0;
        c.gridy = 6;
        c.gridwidth = 3; 
        c.anchor = GridBagConstraints.CENTER;
        
        JButton btnBack = new JButton("Back");

        
        btnBack.setPreferredSize(new Dimension(120, 35));
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.setBackground(new Color(220,20,60));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);

        
        btnBack.addActionListener(e -> {
            this.dispose(); 
            new DashboardGUI();
        });

        panel.add(btnBack, c);

      
        c.gridwidth = 1;
        c.anchor = GridBagConstraints.WEST;

        
        btnSearch.addActionListener(this::searchBook);
        btnUpdate.addActionListener(this::updateBook);

        setVisible(true);
    }

    private void searchBook(ActionEvent e) {
        String id = txtBookId.getText().trim();

        if (id.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Enter Book ID");
            return;
        }

        Book book = bookDAO.getBookByIdFromDB(id);

        if (book == null) {
            JOptionPane.showMessageDialog(this, "Book Not Found!");
            return;
        }

        currentBook = book;

        txtTitle.setEnabled(true);
        txtAuthor.setEnabled(true);
        chkBorrowed.setEnabled(true);
        btnUpdate.setEnabled(true);

        txtTitle.setText(book.getTitle());
        txtAuthor.setText(book.getAuthor());
        chkBorrowed.setSelected(book.isBorrowed());
    }

    private void updateBook(ActionEvent e) {
        if (currentBook == null) return;

        currentBook.setTitle(txtTitle.getText().trim());
        currentBook.setAuthor(txtAuthor.getText().trim());

        if (chkBorrowed.isSelected()) {
            currentBook.borrow();
        } else {
            currentBook.returned();
        }

        boolean success = bookDAO.updateItem(currentBook);

        JOptionPane.showMessageDialog(this,
                success ? "Book Updated Successfully!" : "Update Failed!");
    }

    public static void main(String[] args) {
        new UpdateBookGUI(null);
    }
}
