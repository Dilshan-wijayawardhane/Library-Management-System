package library_management_system_GUI;

import library_management_system.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;

import library_management_system.BackgroundPanel;
import library_management_system.Role;
import library_management_system.User;
import library_management_system_dao.DBConnection;

import java.util.List;

public class ViewUserGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTable tableUsers;
    private List<User> userList;

    public ViewUserGUI(List<User> users) {
       
        this.userList = loadUsersFromDB();
        initializeGUI();
    }

    private void initializeGUI() {
        setTitle("View Users");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 650, 450);
        setLocationRelativeTo(null);

        contentPane = new BackgroundPanel("viewuser.jfif");
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("User Details");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 32));
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setBounds(220, 20, 300, 40);
        contentPane.add(lblTitle);

        String[] columnNames = {"User ID", "Username", "Role"};
        DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        tableUsers = new JTable(tableModel);
        tableUsers.setFont(new Font("Tahoma", Font.PLAIN, 16));
        tableUsers.setRowHeight(28);
        tableUsers.setFillsViewportHeight(true);
        tableUsers.setSelectionBackground(new Color(102, 204, 255));
        tableUsers.setSelectionForeground(Color.BLACK);
        tableUsers.setShowGrid(true);
        tableUsers.setGridColor(Color.LIGHT_GRAY);
        tableUsers.setAutoCreateRowSorter(true);

        JTableHeader header = tableUsers.getTableHeader();
        header.setBackground(new Color(0, 102, 204));
        header.setForeground(Color.WHITE);
        header.setFont(new Font("Tahoma", Font.BOLD, 18));

        DefaultTableCellRenderer centerRenderer = new DefaultTableCellRenderer();
        centerRenderer.setHorizontalAlignment(SwingConstants.CENTER);
        for (int i = 0; i < tableUsers.getColumnCount(); i++) {
            tableUsers.getColumnModel().getColumn(i).setCellRenderer(centerRenderer);
        }

    
        for (User u : userList) {
            tableModel.addRow(new Object[]{
                u.getUserID(),
                u.getUsername(),
                u.getRole()
            });
        }

        JScrollPane scrollPane = new JScrollPane(tableUsers);
        scrollPane.setBounds(50, 80, 550, 250);
        scrollPane.getViewport().setBackground(new Color(255, 255, 255, 180));
        contentPane.add(scrollPane);

        JButton btnBack = new JButton("Back");
        btnBack.setFont(new Font("Tahoma", Font.BOLD, 18));
        btnBack.setBounds(270, 350, 100, 30);
        btnBack.addActionListener(e -> dispose());
        contentPane.add(btnBack);
    }

   
    private List<User> loadUsersFromDB() {
        List<User> list = new ArrayList<>();

        String sql = "SELECT user_id, username, role FROM User";

        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
            	Role role = Role.valueOf(
            	        rs.getString("role").toUpperCase().trim()
            	);

            	User u = new User(
            	        rs.getString("user_id"),
            	        rs.getString("username"),
            	        "********",   
            	        role
            	);
                list.add(u);
            }

        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this,
                    "Error loading users from database",
                    "DB Error",
                    JOptionPane.ERROR_MESSAGE);
        }

        return list;
    }
}
