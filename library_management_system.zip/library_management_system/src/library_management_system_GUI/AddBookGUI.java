package library_management_system_GUI;

import library_management_system.*;

import java.awt.*;
import javax.swing.*;

public class AddBookGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtBookId, txtBookName, txtAuthor;
    private LibraryService libraryService;

    public AddBookGUI(LibraryService libraryService) {
        this.libraryService = libraryService;

        setTitle("Add Book");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 450, 300);
        setLocationRelativeTo(null);

        contentPane = new BackgroundPanel("images (1).png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Add Book");
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 24));
        lblTitle.setBounds(130, 10, 200, 40);
        contentPane.add(lblTitle);

        JLabel lblBookID = new JLabel("Book ID:");
        lblBookID.setForeground(Color.WHITE);
        lblBookID.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblBookID.setBounds(50, 60, 100, 25);
        contentPane.add(lblBookID);

        txtBookId = new JTextField();
        txtBookId.setBounds(150, 60, 200, 25);
        contentPane.add(txtBookId);

        JLabel lblBookName = new JLabel("Title:");
        lblBookName.setForeground(Color.WHITE);
        lblBookName.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblBookName.setBounds(50, 100, 100, 25);
        contentPane.add(lblBookName);

        txtBookName = new JTextField();
        txtBookName.setBounds(150, 100, 200, 25);
        contentPane.add(txtBookName);

        JLabel lblAuthor = new JLabel("Author:");
        lblAuthor.setForeground(Color.WHITE);
        lblAuthor.setFont(new Font("Times New Roman", Font.BOLD, 20));
        lblAuthor.setBounds(50, 140, 100, 25);
        contentPane.add(lblAuthor);

        txtAuthor = new JTextField();
        txtAuthor.setBounds(150, 140, 200, 25);
        contentPane.add(txtAuthor);

        JButton btnAdd = new JButton("Add Book");
        btnAdd.setBounds(130, 190, 180, 40);
        btnAdd.setFont(new Font("Tahoma", Font.BOLD, 16));
        btnAdd.setBackground(new Color(40, 167, 69));
        btnAdd.setForeground(Color.WHITE);
        contentPane.add(btnAdd);

        btnAdd.addActionListener(e -> {
            String id = txtBookId.getText().trim();
            String title = txtBookName.getText().trim();
            String author = txtAuthor.getText().trim();

          
            if (id.isEmpty() || title.isEmpty() || author.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
  
            if (!id.matches("^B\\d+$")) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Book ID! Must start with 'B' followed by numbers.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            
            try {
                Book book = new Book(id, title, author);
                libraryService.addItem(book);
                
                JOptionPane.showMessageDialog(this,"Book added successfully!","Success",JOptionPane.INFORMATION_MESSAGE);
                
                txtBookId.setText("");
                txtBookName.setText("");
                txtAuthor.setText("");

            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,"Database insert failed!","Error", JOptionPane.ERROR_MESSAGE );
            }
        });


        JButton backBtn = new JButton("Back");
        backBtn.setBounds(20, 190, 90, 40);
        backBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        backBtn.addActionListener(e -> dispose());
        contentPane.add(backBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(330, 190, 90, 40);
        exitBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        exitBtn.addActionListener(e -> System.exit(0));
        contentPane.add(exitBtn);
    }
}
