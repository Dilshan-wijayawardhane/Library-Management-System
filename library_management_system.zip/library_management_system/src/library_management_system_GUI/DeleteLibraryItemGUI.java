package library_management_system_GUI;

import library_management_system_dao.*;
import library_management_system.BackgroundPanel;
import library_management_system.LibraryItem;
import library_management_system.User;

import javax.swing.*;
import java.awt.*;
import java.util.List;

public class DeleteLibraryItemGUI extends JFrame {

    private JTextField txtId;
    private JButton btnDelete, btnBack;
    private final LibraryItemDAO libraryItemDAO = new LibraryItemDAO();

    

    public DeleteLibraryItemGUI(List<User> userList) {

        setTitle("Delete Library Item");
        setSize(463, 219);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        
        BackgroundPanel contentPane =
                new BackgroundPanel("delete.png");
        contentPane.setLayout(new BorderLayout(10, 10));
        setContentPane(contentPane);

       
        JPanel formPanel = new JPanel(new GridLayout(2, 2, 5, 5));
        formPanel.setOpaque(false); 

        JLabel lbl = new JLabel("Item ID to Delete:");
        lbl.setFont(new Font("Arial", Font.BOLD, 18));
        lbl.setForeground(Color.WHITE);
        formPanel.add(lbl);

        txtId = new JTextField();
        formPanel.add(txtId);

        btnDelete = new JButton("Delete");
        formPanel.add(new JLabel());
        formPanel.add(btnDelete);

        contentPane.add(formPanel, BorderLayout.CENTER);

      
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bottomPanel.setOpaque(false); 

        btnBack = new JButton("Back");
        btnBack.setBackground(new Color(220, 53, 69));
        btnBack.setForeground(Color.WHITE);
        bottomPanel.add(btnBack);

        contentPane.add(bottomPanel, BorderLayout.SOUTH);

      
        btnDelete.addActionListener(e -> {
            String id = txtId.getText().trim();
            if (id.isEmpty()) {
                JOptionPane.showMessageDialog(this,
                        "Please enter an Item ID!",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!id.matches("^LI\\d+$")) {
                JOptionPane.showMessageDialog(this,
                        "Invalid Item ID! Must start with 'LI' followed by numbers.",
                        "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            boolean success = libraryItemDAO.delete(id);
            if (success) {
                JOptionPane.showMessageDialog(this,
                        "Item deleted successfully!");
                txtId.setText("");
            } else {
                JOptionPane.showMessageDialog(this,
                        "Item not found or delete failed!",
                        "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        btnBack.addActionListener(e -> dispose());
        setVisible(true);
    }
}
