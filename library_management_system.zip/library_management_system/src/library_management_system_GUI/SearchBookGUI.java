package library_management_system_GUI;

import library_management_system.*;
import library_management_system_dao.*;
import java.awt.*;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import javax.swing.*;

public class SearchBookGUI extends JFrame {

    private static final long serialVersionUID = 1L;
    private JPanel contentPane;
    private JTextField txtSearch;
    private JLabel lblResult;
    private LibraryService libraryService;

    public SearchBookGUI(LibraryService libraryService) {
        this.libraryService = libraryService;

        setTitle("Search Book");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setBounds(100, 100, 500, 350);
        setLocationRelativeTo(null);

        contentPane = new BackgroundPanel("images (2).png");
        contentPane.setLayout(null);
        setContentPane(contentPane);

        JLabel lblTitle = new JLabel("Search Book");
        lblTitle.setForeground(Color.WHITE);
        lblTitle.setFont(new Font("Tahoma", Font.BOLD, 30));
        lblTitle.setBounds(140, 20, 250, 40);
        contentPane.add(lblTitle);

        txtSearch = new JTextField();
        txtSearch.setBounds(100, 90, 300, 30);
        contentPane.add(txtSearch);

        JButton btnSearch = new JButton("Search");
        btnSearch.setBounds(200, 140, 100, 30);
        contentPane.add(btnSearch);

        lblResult = new JLabel("");
        lblResult.setForeground(Color.BLACK);
        lblResult.setFont(new Font("Tahoma", Font.PLAIN, 16));
        lblResult.setBounds(50, 200, 400, 30);
        contentPane.add(lblResult);

        JButton backBtn = new JButton("Back");
        backBtn.setBounds(50, 280, 90, 30);
        backBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        backBtn.addActionListener(e -> dispose());
        contentPane.add(backBtn);

        JButton exitBtn = new JButton("Exit");
        exitBtn.setBounds(350, 280, 90, 30);
        exitBtn.setFont(new Font("Tahoma", Font.BOLD, 16));
        exitBtn.addActionListener(e -> System.exit(0));
        contentPane.add(exitBtn);

       
        btnSearch.addActionListener(e -> {

            String query = txtSearch.getText().trim().toLowerCase();
            boolean found = false;

           
            List<LibraryItem> items = libraryService.getAllItems();
            for (LibraryItem item : items) {
                if (item instanceof Book book) {
                    if (book.getId().toLowerCase().equals(query)
                            || book.getTitle().toLowerCase().contains(query)) {

                        lblResult.setText(
                                "Found: " + book.getTitle() +
                                " by " + book.getAuthor() +
                                " (ID: " + book.getId() + ")"
                        );
                        found = true;
                        break;
                    }
                }
            }

           
            if (!found) {
                String sql = "SELECT book_id, title, author FROM Book " +
                             "WHERE LOWER(book_id) = ? OR LOWER(title) LIKE ?";

                try (Connection conn = DBConnection.getConnection();
                     PreparedStatement ps = conn.prepareStatement(sql)) {

                    ps.setString(1, query);
                    ps.setString(2, "%" + query + "%");

                    ResultSet rs = ps.executeQuery();

                    if (rs.next()) {
                        lblResult.setText(
                                "Book Found (DB): " +
                                rs.getString("title") +
                                " by " +
                                rs.getString("author") +
                                " (ID: " +
                                rs.getString("book_id") +
                                ")"
                        );
                        found = true;
                    }

                } catch (Exception ex) {
                    ex.printStackTrace();
                    lblResult.setText("Database error!");
                    return;
                }
            }

           
            if (!found) {
                lblResult.setText("Book not found!");
            }
        });
    }
}