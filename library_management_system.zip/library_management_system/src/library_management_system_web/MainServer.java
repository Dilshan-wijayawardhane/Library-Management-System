package library_management_system_web;

import com.sun.net.httpserver.HttpServer;
import java.net.InetSocketAddress;
import java.util.logging.Logger;

public class MainServer {

    private static final Logger logger = Logger.getLogger(MainServer.class.getName());

    public static void main(String[] args) throws Exception {

        HttpServer server = HttpServer.create(new InetSocketAddress(8080), 0);

        server.createContext("/books", new BookHandler());
        server.createContext("/users", new UserHandler());

        server.setExecutor(null); 
        server.start();

        logger.info("REST Server started on http://localhost:8080");
    }
}
