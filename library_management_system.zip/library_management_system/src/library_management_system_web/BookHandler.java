package library_management_system_web;

import com.sun.net.httpserver.*;
import library_management_system.*;
import library_management_system_dao.BookDAO;

import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.logging.Logger;

public class BookHandler implements HttpHandler {

    private static final Logger logger = Logger.getLogger(BookHandler.class.getName());
    private final BookDAO bookDAO = new BookDAO();

    @Override
    public void handle(HttpExchange exchange) throws IOException {

        try {
            String method = exchange.getRequestMethod();
            URI uri = exchange.getRequestURI();
            String query = uri.getQuery();

            logger.info(method + " " + uri);

            switch (method) {
                case "GET":
                    handleGet(exchange, query);
                    break;
                case "POST":
                    handlePost(exchange);
                    break;
                case "PUT":
                    handlePut(exchange, query);
                    break;
                case "DELETE":
                    handleDelete(exchange, query);
                    break;
                default:
                    sendResponse(exchange, 405, "Method Not Allowed");
            }

        } catch (Exception e) {
            logger.severe(e.getMessage());
            sendResponse(exchange, 500, "Internal Server Error");
        }
    }

    private void handleGet(HttpExchange ex, String query) throws IOException {

        StringBuilder html = new StringBuilder();
        html.append("""
            <html>
            <head>
                <title>Library Books</title>
                <style>
                    body { font-family: Arial, sans-serif; background: #f4f6f8; padding: 30px; }
                    h2 { text-align: center; }
                    table { width: 80%; margin: auto; border-collapse: collapse; background: white; box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
                    th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
                    th { background-color: #2c3e50; color: white; }
                    tr:hover { background-color: #f1f1f1; }
                </style>
            </head>
            <body>
                <h2>📚 Library Book List</h2>
                <table>
                    <tr>
                        <th>ID</th>
                        <th>Title</th>
                        <th>Author</th>
                        <th>Borrowed</th>
                    </tr>
        """);

        if (query != null && query.contains("id=")) {
           
            String id = null;
            for (String param : query.split("&")) {
                if (param.startsWith("id=")) {
                    id = param.substring(3);
                    break;
                }
            }

            if (id != null && !id.isEmpty()) {
                Book book = bookDAO.getBookByIdFromDB(id);
                if (book != null) {
                    html.append("""
                        <tr>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                        </tr>
                    """.formatted(
                            book.getId(),
                            book.getTitle(),
                            book.getAuthor(),
                            book.isBorrowed() ? "Yes" : "No"
                    ));
                } else {
                    html.append("""
                        <tr><td colspan='4'>Book not found</td></tr>
                    """);
                }
            }
        } else {
           
            List<Book> books = bookDAO.getAllBooksFromDB();
            for (Book b : books) {
                html.append("""
                    <tr>
                        <td>%s</td>
                        <td>%s</td>
                        <td>%s</td>
                        <td>%s</td>
                    </tr>
                """.formatted(
                        b.getId(),
                        b.getTitle(),
                        b.getAuthor(),
                        b.isBorrowed() ? "Yes" : "No"
                ));
            }
        }

        html.append("""
                </table>
            </body>
            </html>
        """);

        sendResponse(ex, 200, html.toString());
    }



    private void handlePost(HttpExchange ex) throws IOException {
        String body = readBody(ex);
        String[] data = body.split(",");

        if (data.length < 3) {
            sendResponse(ex, 400, "Invalid input");
            return;
        }

        Book book = new Book(data[0], data[1], data[2]);
        boolean success = bookDAO.addBook(book);

        sendResponse(ex, success ? 201 : 400,
                success ? "Book created" : "Failed to create book");
    }

    private void handlePut(HttpExchange ex, String query) throws IOException {
        if (query == null || !query.startsWith("id=")) {
            sendResponse(ex, 400, "Missing book id");
            return;
        }

        String id = query.split("=")[1];
        String body = readBody(ex);
        String[] data = body.split(",");

        Book book = new Book(id, data[0], data[1]);
        boolean success = bookDAO.updateItem(book);

        sendResponse(ex, success ? 200 : 404,
                success ? "Book updated" : "Book not found");
    }

    private void handleDelete(HttpExchange ex, String query) throws IOException {
        if (query == null || !query.startsWith("id=")) {
            sendResponse(ex, 400, "Missing book id");
            return;
        }

        String id = query.split("=")[1];
        boolean success = bookDAO.deleteBook(id);

        sendResponse(ex, success ? 200 : 404,
                success ? "Book deleted" : "Book not found");
    }

    private String readBody(HttpExchange ex) throws IOException {
        return new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private void sendResponse(HttpExchange ex, int code, String html) throws IOException {
        ex.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
        ex.sendResponseHeaders(code, html.getBytes().length);
        ex.getResponseBody().write(html.getBytes());
        ex.close();
    }

}
