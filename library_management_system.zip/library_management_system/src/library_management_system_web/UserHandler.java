package library_management_system_web;

import com.sun.net.httpserver.*;
import library_management_system.*;
import library_management_system_dao.UserDAO;

import java.io.*;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.logging.Logger;

public class UserHandler implements HttpHandler {

    private static final Logger logger = Logger.getLogger(UserHandler.class.getName());
    private final UserDAO userDAO = new UserDAO();

    @Override
    public void handle(HttpExchange ex) throws IOException {

        try {
            String method = ex.getRequestMethod();
            URI uri = ex.getRequestURI();
            String query = uri.getQuery();

            logger.info(method + " " + uri);

            switch (method) {
                case "GET":
                    handleGet(ex, query);
                    break;
                case "POST":
                    handlePost(ex);
                    break;
                case "PUT":
                    handlePut(ex, query);
                    break;
                case "DELETE":
                    handleDelete(ex, query);
                    break;
                default:
                    sendResponse(ex, 405, "Method Not Allowed");
            }

        } catch (Exception e) {
            logger.severe(e.getMessage());
            sendResponse(ex, 500, "Internal Server Error");
        }
    }

    private void handleGet(HttpExchange ex, String query) throws IOException {

        StringBuilder html = new StringBuilder();
        html.append("""
            <html>
            <head>
                <title>Library Users</title>
                <style>
                    body { font-family: Arial, sans-serif; background: #f4f6f8; padding: 30px; }
                    h2 { text-align: center; }
                    table { width: 80%; margin: auto; border-collapse: collapse; background: white;
                            box-shadow: 0 4px 10px rgba(0,0,0,0.1); }
                    th, td { padding: 12px; text-align: center; border-bottom: 1px solid #ddd; }
                    th { background-color: #2c3e50; color: white; }
                    tr:hover { background-color: #f1f1f1; }
                </style>
            </head>
            <body>
                <h2>👤 Library Users</h2>
                <table>
                    <tr>
                        <th>User ID</th>
                        <th>Username</th>
                        <th>Role</th>
                    </tr>
        """);

        if (query != null && query.contains("id=")) {

            String id = null;
            for (String param : query.split("&")) {
                if (param.startsWith("id=")) {
                    id = param.substring(3);
                    break;
                }
            }

            if (id != null && !id.isEmpty()) {
                User user = userDAO.findById(id);

                if (user != null) {
                    html.append("""
                        <tr>
                            <td>%s</td>
                            <td>%s</td>
                            <td>%s</td>
                        </tr>
                    """.formatted(
                            user.getUserID(),
                            user.getUsername(),
                            user.getRole()
                    ));
                } else {
                    html.append("""
                        <tr>
                            <td colspan="3">User not found</td>
                        </tr>
                    """);
                }
            }

        } else {
          
            for (User u : userDAO.findAll()) {
                html.append("""
                    <tr>
                        <td>%s</td>
                        <td>%s</td>
                        <td>%s</td>
                    </tr>
                """.formatted(
                        u.getUserID(),
                        u.getUsername(),
                        u.getRole()
                ));
            }
        }

        html.append("""
                </table>
            </body>
            </html>
        """);

        sendResponse(ex, 200, html.toString());
    }

    private void handlePost(HttpExchange ex) throws IOException {
        String[] data = readBody(ex).split(",");

        User user = new User(data[0], data[1], data[2], Role.valueOf(data[3]));
        boolean success = userDAO.save(user, data[2]);

        sendResponse(ex, success ? 201 : 400,
                success ? "User created" : "Failed to create user");
    }

    private void handlePut(HttpExchange ex, String query) throws IOException {
        String id = query.split("=")[1];
        String[] data = readBody(ex).split(",");

        User user = new User(id, data[0], data[1], Role.valueOf(data[2]));
        boolean success = userDAO.update(user, data[1]);

        sendResponse(ex, success ? 200 : 404,
                success ? "User updated" : "User not found");
    }

    private void handleDelete(HttpExchange ex, String query) throws IOException {
        String id = query.split("=")[1];
        boolean success = userDAO.delete(id);

        sendResponse(ex, success ? 200 : 404,
                success ? "User deleted" : "User not found");
    }

    private String readBody(HttpExchange ex) throws IOException {
        return new String(ex.getRequestBody().readAllBytes(), StandardCharsets.UTF_8);
    }

    private void sendResponse(HttpExchange ex, int code, String html) throws IOException {
        ex.getResponseHeaders().add("Content-Type", "text/html; charset=UTF-8");
        ex.sendResponseHeaders(code, html.getBytes().length);
        ex.getResponseBody().write(html.getBytes());
        ex.close();
    }

}
